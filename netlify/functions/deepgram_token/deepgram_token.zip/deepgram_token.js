var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));

// netlify/functions/deepgram_token/node_modules/@deepgram/sdk/dist/index.js
var require_dist = __commonJS({
  "netlify/functions/deepgram_token/node_modules/@deepgram/sdk/dist/index.js"(exports2, module2) {
    !function(e, t) {
      typeof exports2 == "object" && typeof module2 == "object" ? module2.exports = t() : typeof define == "function" && define.amd ? define([], t) : typeof exports2 == "object" ? exports2["dg-node-sdk"] = t() : e["dg-node-sdk"] = t();
    }(global, () => (() => {
      var e = { 5343: function(e2, t2) {
        "use strict";
        var r2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, n2 = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
            return this;
          }), s;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s && (s = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Billing = void 0;
        var i = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.listBalances = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4, "/balances"))];
              });
            });
          }, e3.prototype.getBalance = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(e4, "/balances/").concat(t3))];
              });
            });
          }, e3;
        }();
        t2.Billing = i;
      }, 6688: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.DefaultOptions = void 0, t2.DefaultOptions = { apiUrl: "api.deepgram.com", requireSSL: true };
      }, 6092: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__createBinding || (Object.create ? function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3);
          var i2 = Object.getOwnPropertyDescriptor(t3, r3);
          i2 && !("get" in i2 ? !t3.__esModule : i2.writable || i2.configurable) || (i2 = { enumerable: true, get: function() {
            return t3[r3];
          } }), Object.defineProperty(e3, n3, i2);
        } : function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3), e3[n3] = t3[r3];
        }), i = this && this.__exportStar || function(e3, t3) {
          for (var r3 in e3)
            r3 === "default" || Object.prototype.hasOwnProperty.call(t3, r3) || n2(t3, e3, r3);
        };
        Object.defineProperty(t2, "__esModule", { value: true }), i(r2(6688), t2);
      }, 2625: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 1447: (e2, t2) => {
        "use strict";
        var r2;
        Object.defineProperty(t2, "__esModule", { value: true }), t2.ConnectionState = void 0, (r2 = t2.ConnectionState || (t2.ConnectionState = {}))[r2.CONNECTING = 0] = "CONNECTING", r2[r2.OPEN = 1] = "OPEN", r2[r2.CLOSING = 2] = "CLOSING", r2[r2.CLOSED = 3] = "CLOSED";
      }, 5153: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6121: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__createBinding || (Object.create ? function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3);
          var i2 = Object.getOwnPropertyDescriptor(t3, r3);
          i2 && !("get" in i2 ? !t3.__esModule : i2.writable || i2.configurable) || (i2 = { enumerable: true, get: function() {
            return t3[r3];
          } }), Object.defineProperty(e3, n3, i2);
        } : function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3), e3[n3] = t3[r3];
        }), i = this && this.__exportStar || function(e3, t3) {
          for (var r3 in e3)
            r3 === "default" || Object.prototype.hasOwnProperty.call(t3, r3) || n2(t3, e3, r3);
        };
        Object.defineProperty(t2, "__esModule", { value: true }), i(r2(2625), t2), i(r2(1447), t2), i(r2(5153), t2), i(r2(2843), t2), i(r2(5754), t2), i(r2(3544), t2), i(r2(5272), t2);
      }, 2843: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5754: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 3544: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5272: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5483: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__createBinding || (Object.create ? function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3);
          var i2 = Object.getOwnPropertyDescriptor(t3, r3);
          i2 && !("get" in i2 ? !t3.__esModule : i2.writable || i2.configurable) || (i2 = { enumerable: true, get: function() {
            return t3[r3];
          } }), Object.defineProperty(e3, n3, i2);
        } : function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3), e3[n3] = t3[r3];
        }), i = this && this.__exportStar || function(e3, t3) {
          for (var r3 in e3)
            r3 === "default" || Object.prototype.hasOwnProperty.call(t3, r3) || n2(t3, e3, r3);
        };
        Object.defineProperty(t2, "__esModule", { value: true }), i(r2(9489), t2), i(r2(2795), t2);
      }, 9489: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.secondsToTimestamp = void 0;
        var i = n2(r2(7484)), s = n2(r2(178));
        i.default.extend(s.default), t2.secondsToTimestamp = function(e3, t3) {
          return t3 === void 0 && (t3 = "HH:mm:ss.SSS"), (0, i.default)(1e3 * e3).utc().format(t3);
        };
      }, 2795: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.validateOptions = void 0, t2.validateOptions = function(e3, t3) {
          if (!e3 || e3.trim().length === 0)
            throw new Error("DG: API key is required");
          if (!t3 || t3.trim().length === 0)
            throw new Error("DG: API url should be a valid url or not provided");
        };
      }, 1098: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__assign || function() {
          return n2 = Object.assign || function(e3) {
            for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
              for (var i2 in t3 = arguments[r3])
                Object.prototype.hasOwnProperty.call(t3, i2) && (e3[i2] = t3[i2]);
            return e3;
          }, n2.apply(this, arguments);
        }, i = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2._request = void 0;
        var s = r2(2781), o = i(r2(5687)), a = i(r2(3685)), c = r2(1408);
        t2._request = function(e3, t3, r3, i2, u, l, h) {
          var f = function(e4, t4, r4, i3, o2, a2, u2) {
            var l2 = {};
            !a2 || a2 instanceof s.Readable || (l2["Content-Length"] = Buffer.byteLength(a2));
            var h2 = { host: t4, protocol: r4 ? "https:" : "http:", path: i3, method: o2, headers: n2({ "User-Agent": (0, c.userAgent)(), "Content-Type": "application/json", Authorization: "token ".concat(e4) }, l2) }, f2 = h2.headers;
            return u2 && u2.headers && (f2 = n2(n2({}, f2), u2.headers)), n2(n2(n2({}, h2), u2), { headers: f2 });
          }(t3, r3, i2, u, e3, l, h);
          return new Promise(function(e4, t4) {
            try {
              var r4 = (i2 ? o.default : a.default).request(f, function(r5) {
                var n3 = "";
                r5.on("data", function(e5) {
                  n3 += e5;
                }), r5.on("end", function() {
                  var i3;
                  try {
                    i3 = JSON.parse(n3);
                  } catch (e5) {
                    i3 = { error: n3 };
                  }
                  r5.statusCode && r5.statusCode >= 400 && (i3.error, t4("DG: ".concat(JSON.stringify(i3)))), i3.error && t4("DG: ".concat(n3)), e4(i3);
                }), r5.on("error", function(e5) {
                  t4("DG: ".concat(e5));
                });
              });
              r4.on("error", function(e5) {
                t4("DG: ".concat(e5));
              }), l ? l instanceof s.Readable ? (l.pipe(r4), l.on("finish", function() {
                r4.end();
              })) : (r4.write(l), r4.end()) : r4.end();
            } catch (e5) {
              t4("DG: ".concat(e5));
            }
          });
        };
      }, 6359: function(e2, t2) {
        "use strict";
        var r2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, n2 = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
            return this;
          }), s;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s && (s = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Invitation = void 0;
        var i = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.list = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4, "/invites"))];
              });
            });
          }, e3.prototype.send = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("POST", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(e4, "/invites"), JSON.stringify({ email: t3.email, scope: t3.scope }))];
              });
            });
          }, e3.prototype.leave = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("DELETE", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4, "/leave"))];
              });
            });
          }, e3.prototype.delete = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("DELETE", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(e4, "/invites/").concat(t3))];
              });
            });
          }, e3;
        }();
        t2.Invitation = i;
      }, 9292: function(e2, t2) {
        "use strict";
        var r2 = this && this.__assign || function() {
          return r2 = Object.assign || function(e3) {
            for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
              for (var i2 in t3 = arguments[r3])
                Object.prototype.hasOwnProperty.call(t3, i2) && (e3[i2] = t3[i2]);
            return e3;
          }, r2.apply(this, arguments);
        }, n2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s2) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, i = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s2, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s2 = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s2[Symbol.iterator] = function() {
            return this;
          }), s2;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s2 && (s2 = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Keys = void 0;
        var s = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.list = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), n2(this, void 0, void 0, function() {
              return i(this, function(n3) {
                switch (n3.label) {
                  case 0:
                    return [4, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4, "/keys"))];
                  case 1:
                    return [2, { api_keys: n3.sent().api_keys.map(function(e5) {
                      return r2(r2({}, e5), e5.api_key);
                    }) }];
                }
              });
            });
          }, e3.prototype.get = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), n2(this, void 0, void 0, function() {
              return i(this, function(n3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/keys/").concat(t3))];
              });
            });
          }, e3.prototype.create = function(e4, t3, r3, s2, o) {
            return o === void 0 && (o = "v1/projects"), n2(this, void 0, void 0, function() {
              return i(this, function(n3) {
                if (s2 && s2.expirationDate !== void 0 && s2.timeToLive !== void 0)
                  throw new Error("Please provide expirationDate or timeToLive or neither. Providing both is not allowed.");
                return [2, this._request("POST", this._credentials, this._apiUrl, this._requireSSL, "/".concat(o, "/").concat(e4, "/keys"), JSON.stringify({ comment: t3, scopes: r3, expiration_date: s2 && s2.expirationDate ? s2.expirationDate : void 0, time_to_live_in_seconds: s2 && s2.timeToLive ? s2.timeToLive : void 0 }))];
              });
            });
          }, e3.prototype.delete = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), n2(this, void 0, void 0, function() {
              return i(this, function(n3) {
                return [2, this._request("DELETE", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/keys/").concat(t3))];
              });
            });
          }, e3;
        }();
        t2.Keys = s;
      }, 8949: function(e2, t2) {
        "use strict";
        var r2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, n2 = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
            return this;
          }), s;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s && (s = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Members = void 0;
        var i = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.listMembers = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4, "/members"))];
              });
            });
          }, e3.prototype.removeMember = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("DELETE", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(e4, "/members/").concat(t3))];
              });
            });
          }, e3;
        }();
        t2.Members = i;
      }, 319: function(e2, t2) {
        "use strict";
        var r2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, n2 = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
            return this;
          }), s;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s && (s = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Projects = void 0;
        var i = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.list = function(e4) {
            return e4 === void 0 && (e4 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(t3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(e4))];
              });
            });
          }, e3.prototype.get = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4))];
              });
            });
          }, e3.prototype.update = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              var r3, s;
              return n2(this, function(n3) {
                return s = e4, (r3 = e4).project_id && (s = r3.project_id), [2, this._request("PATCH", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(s), JSON.stringify(t3))];
              });
            });
          }, e3.prototype.delete = function(e4, t3) {
            return t3 === void 0 && (t3 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("DELETE", this._credentials, this._apiUrl, this._requireSSL, "/".concat(t3, "/").concat(e4))];
              });
            });
          }, e3;
        }();
        t2.Projects = i;
      }, 3647: function(e2, t2) {
        "use strict";
        var r2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s) {
            function o(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function a(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o, a);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, n2 = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s, o = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s = { next: a(0), throw: a(1), return: a(2) }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
            return this;
          }), s;
          function a(a2) {
            return function(c) {
              return function(a3) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s && (s = 0, a3[0] && (o = 0)), o; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a3[0] ? n3.return : a3[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a3[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a3 = [2 & a3[0], i2.value]), a3[0]) {
                      case 0:
                      case 1:
                        i2 = a3;
                        break;
                      case 4:
                        return o.label++, { value: a3[1], done: false };
                      case 5:
                        o.label++, n3 = a3[1], a3 = [0];
                        continue;
                      case 7:
                        a3 = o.ops.pop(), o.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o.trys).length > 0 && i2[i2.length - 1]) || a3[0] !== 6 && a3[0] !== 2)) {
                          o = 0;
                          continue;
                        }
                        if (a3[0] === 3 && (!i2 || a3[1] > i2[0] && a3[1] < i2[3])) {
                          o.label = a3[1];
                          break;
                        }
                        if (a3[0] === 6 && o.label < i2[1]) {
                          o.label = i2[1], i2 = a3;
                          break;
                        }
                        if (i2 && o.label < i2[2]) {
                          o.label = i2[2], o.ops.push(a3);
                          break;
                        }
                        i2[2] && o.ops.pop(), o.trys.pop();
                        continue;
                    }
                    a3 = t3.call(e3, o);
                  } catch (e4) {
                    a3 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a3[0])
                  throw a3[1];
                return { value: a3[0] ? a3[1] : void 0, done: true };
              }([a2, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Scopes = void 0;
        var i = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.get = function(e4, t3, i2) {
            return i2 === void 0 && (i2 = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(i2, "/").concat(e4, "/members/").concat(t3, "/scopes"))];
              });
            });
          }, e3.prototype.update = function(e4, t3, i2, s) {
            return s === void 0 && (s = "v1/projects"), r2(this, void 0, void 0, function() {
              return n2(this, function(r3) {
                return [2, this._request("PUT", this._credentials, this._apiUrl, this._requireSSL, "/".concat(s, "/").concat(e4, "/members/").concat(t3, "/scopes"), JSON.stringify({ scope: i2 }))];
              });
            });
          }, e3;
        }();
        t2.Scopes = i;
      }, 487: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s2) {
            function o2(e4) {
              try {
                c(n3.next(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function a2(e4) {
              try {
                c(n3.throw(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function c(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o2, a2);
            }
            c((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, i = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s2, o2 = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s2 = { next: a2(0), throw: a2(1), return: a2(2) }, typeof Symbol == "function" && (s2[Symbol.iterator] = function() {
            return this;
          }), s2;
          function a2(a3) {
            return function(c) {
              return function(a4) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s2 && (s2 = 0, a4[0] && (o2 = 0)), o2; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a4[0] ? n3.return : a4[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a4[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a4 = [2 & a4[0], i2.value]), a4[0]) {
                      case 0:
                      case 1:
                        i2 = a4;
                        break;
                      case 4:
                        return o2.label++, { value: a4[1], done: false };
                      case 5:
                        o2.label++, n3 = a4[1], a4 = [0];
                        continue;
                      case 7:
                        a4 = o2.ops.pop(), o2.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o2.trys).length > 0 && i2[i2.length - 1]) || a4[0] !== 6 && a4[0] !== 2)) {
                          o2 = 0;
                          continue;
                        }
                        if (a4[0] === 3 && (!i2 || a4[1] > i2[0] && a4[1] < i2[3])) {
                          o2.label = a4[1];
                          break;
                        }
                        if (a4[0] === 6 && o2.label < i2[1]) {
                          o2.label = i2[1], i2 = a4;
                          break;
                        }
                        if (i2 && o2.label < i2[2]) {
                          o2.label = i2[2], o2.ops.push(a4);
                          break;
                        }
                        i2[2] && o2.ops.pop(), o2.trys.pop();
                        continue;
                    }
                    a4 = t3.call(e3, o2);
                  } catch (e4) {
                    a4 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a4[0])
                  throw a4[1];
                return { value: a4[0] ? a4[1] : void 0, done: true };
              }([a3, c]);
            };
          }
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Transcriber = void 0;
        var s = r2(5379), o = r2(3825), a = function() {
          function e3(e4, t3, r3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3;
          }
          return e3.prototype.preRecorded = function(e4, t3, r3) {
            return n2(this, void 0, void 0, function() {
              return i(this, function(n3) {
                switch (n3.label) {
                  case 0:
                    return [4, (0, o.preRecordedTranscription)(this._credentials, this._apiUrl || "", this._requireSSL, e4, t3, r3)];
                  case 1:
                    return [2, n3.sent()];
                }
              });
            });
          }, e3.prototype.live = function(e4, t3) {
            return new s.LiveTranscription(this._credentials, this._apiUrl || "", this._requireSSL, e4, t3);
          }, e3;
        }();
        t2.Transcriber = a;
      }, 5379: function(e2, t2, r2) {
        "use strict";
        var n2, i = this && this.__extends || (n2 = function(e3, t3) {
          return n2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e4, t4) {
            e4.__proto__ = t4;
          } || function(e4, t4) {
            for (var r3 in t4)
              Object.prototype.hasOwnProperty.call(t4, r3) && (e4[r3] = t4[r3]);
          }, n2(e3, t3);
        }, function(e3, t3) {
          if (typeof t3 != "function" && t3 !== null)
            throw new TypeError("Class extends value " + String(t3) + " is not a constructor or null");
          function r3() {
            this.constructor = e3;
          }
          n2(e3, t3), e3.prototype = t3 === null ? Object.create(t3) : (r3.prototype = t3.prototype, new r3());
        }), s = this && this.__assign || function() {
          return s = Object.assign || function(e3) {
            for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
              for (var i2 in t3 = arguments[r3])
                Object.prototype.hasOwnProperty.call(t3, i2) && (e3[i2] = t3[i2]);
            return e3;
          }, s.apply(this, arguments);
        }, o = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.LiveTranscription = void 0;
        var a = o(r2(2361)), c = o(r2(3477)), u = o(r2(8777)), l = r2(6121), h = r2(1408), f = function(e3) {
          function t3(t4, r3, n3, i2, o2) {
            o2 === void 0 && (o2 = "v1/listen");
            var a2 = e3.call(this, void 0) || this, l2 = s({}, i2), f2 = n3 ? "wss" : "ws";
            return a2._socket = new u.default("".concat(f2, "://").concat(r3, "/").concat(o2, "?").concat(c.default.stringify(l2)), { headers: { Authorization: "token ".concat(t4), "User-Agent": (0, h.userAgent)() } }), a2._bindSocketEvents(), a2;
          }
          return i(t3, e3), t3.prototype._bindSocketEvents = function() {
            var e4 = this;
            this._socket.onopen = function() {
              e4.emit("open", e4);
            }, this._socket.onclose = function(t4) {
              var r3 = t4.target;
              if (r3._req) {
                var n3 = r3._req.res.rawHeaders.indexOf("dg-error");
                t4.reason = r3._req.res.rawHeaders[n3 + 1];
              }
              e4.emit("close", t4);
            }, this._socket.onerror = function(t4) {
              e4.emit("error", t4);
            }, this._socket.onmessage = function(t4) {
              e4.emit("transcriptReceived", t4.data);
            };
          }, t3.prototype.configure = function(e4) {
            this._socket.send(JSON.stringify({ type: "Configure", processors: e4 }));
          }, t3.prototype.keepAlive = function() {
            this._socket.send(JSON.stringify({ type: "KeepAlive" }));
          }, t3.prototype.getReadyState = function() {
            return this._socket.readyState;
          }, t3.prototype.send = function(e4) {
            this._socket.readyState === l.ConnectionState.OPEN ? this._socket.send(e4) : this.emit("error", "Could not send. Connection not open.");
          }, t3.prototype.finish = function() {
            this._socket.send(new Uint8Array(0));
          }, t3;
        }(a.default);
        t2.LiveTranscription = f;
      }, 3825: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__assign || function() {
          return n2 = Object.assign || function(e3) {
            for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
              for (var i2 in t3 = arguments[r3])
                Object.prototype.hasOwnProperty.call(t3, i2) && (e3[i2] = t3[i2]);
            return e3;
          }, n2.apply(this, arguments);
        }, i = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s2) {
            function o2(e4) {
              try {
                c2(n3.next(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function a2(e4) {
              try {
                c2(n3.throw(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function c2(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o2, a2);
            }
            c2((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, s = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s2, o2 = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s2 = { next: a2(0), throw: a2(1), return: a2(2) }, typeof Symbol == "function" && (s2[Symbol.iterator] = function() {
            return this;
          }), s2;
          function a2(a3) {
            return function(c2) {
              return function(a4) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s2 && (s2 = 0, a4[0] && (o2 = 0)), o2; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a4[0] ? n3.return : a4[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a4[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a4 = [2 & a4[0], i2.value]), a4[0]) {
                      case 0:
                      case 1:
                        i2 = a4;
                        break;
                      case 4:
                        return o2.label++, { value: a4[1], done: false };
                      case 5:
                        o2.label++, n3 = a4[1], a4 = [0];
                        continue;
                      case 7:
                        a4 = o2.ops.pop(), o2.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o2.trys).length > 0 && i2[i2.length - 1]) || a4[0] !== 6 && a4[0] !== 2)) {
                          o2 = 0;
                          continue;
                        }
                        if (a4[0] === 3 && (!i2 || a4[1] > i2[0] && a4[1] < i2[3])) {
                          o2.label = a4[1];
                          break;
                        }
                        if (a4[0] === 6 && o2.label < i2[1]) {
                          o2.label = i2[1], i2 = a4;
                          break;
                        }
                        if (i2 && o2.label < i2[2]) {
                          o2.label = i2[2], o2.ops.push(a4);
                          break;
                        }
                        i2[2] && o2.ops.pop(), o2.trys.pop();
                        continue;
                    }
                    a4 = t3.call(e3, o2);
                  } catch (e4) {
                    a4 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a4[0])
                  throw a4[1];
                return { value: a4[0] ? a4[1] : void 0, done: true };
              }([a3, c2]);
            };
          }
        }, o = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.preRecordedTranscription = void 0;
        var a = o(r2(3477)), c = r2(3274), u = r2(1098);
        function l(e3) {
          return !!e3.url;
        }
        t2.preRecordedTranscription = function(e3, t3, r3, o2, h, f) {
          return f === void 0 && (f = "v1/listen"), i(void 0, void 0, void 0, function() {
            var i2, d, p, _;
            return s(this, function(s2) {
              switch (s2.label) {
                case 0:
                  if (i2 = n2({}, h), !l(o2) && (o2.mimetype === void 0 || o2.mimetype.length === 0))
                    throw new Error("DG: Mimetype must be provided if the source is a Buffer or a Readable");
                  if (l(o2))
                    d = JSON.stringify(o2);
                  else if (o2.buffer)
                    d = o2.buffer;
                  else {
                    if (!o2.stream)
                      throw new Error("Unknown TranscriptionSource type");
                    d = o2.stream;
                  }
                  return p = {}, l(o2) || (p.headers = { "Content-Type": o2.mimetype }), [4, (0, u._request)("POST", e3, t3, r3, "/".concat(f, "?").concat(a.default.stringify(i2)), d, p)];
                case 1:
                  return _ = s2.sent(), [2, Object.assign(new c.PrerecordedTranscriptionResponse(), _)];
              }
            });
          });
        };
      }, 7660: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7467: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4407: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 9674: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6143: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6513: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5021: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7096: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 3274: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__createBinding || (Object.create ? function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3);
          var i2 = Object.getOwnPropertyDescriptor(t3, r3);
          i2 && !("get" in i2 ? !t3.__esModule : i2.writable || i2.configurable) || (i2 = { enumerable: true, get: function() {
            return t3[r3];
          } }), Object.defineProperty(e3, n3, i2);
        } : function(e3, t3, r3, n3) {
          n3 === void 0 && (n3 = r3), e3[n3] = t3[r3];
        }), i = this && this.__exportStar || function(e3, t3) {
          for (var r3 in e3)
            r3 === "default" || Object.prototype.hasOwnProperty.call(t3, r3) || n2(t3, e3, r3);
        };
        Object.defineProperty(t2, "__esModule", { value: true }), i(r2(7660), t2), i(r2(7467), t2), i(r2(4407), t2), i(r2(9674), t2), i(r2(6143), t2), i(r2(6513), t2), i(r2(7096), t2), i(r2(5642), t2), i(r2(3867), t2), i(r2(7135), t2), i(r2(7569), t2), i(r2(4630), t2), i(r2(1741), t2), i(r2(5395), t2), i(r2(9713), t2), i(r2(2140), t2), i(r2(6397), t2), i(r2(4148), t2), i(r2(5937), t2), i(r2(2135), t2), i(r2(597), t2), i(r2(5086), t2), i(r2(6339), t2), i(r2(838), t2), i(r2(4439), t2), i(r2(2678), t2), i(r2(9266), t2), i(r2(7845), t2), i(r2(5935), t2), i(r2(1562), t2), i(r2(6536), t2), i(r2(393), t2), i(r2(3249), t2), i(r2(2401), t2), i(r2(2e3), t2), i(r2(4019), t2), i(r2(9070), t2), i(r2(2862), t2), i(r2(5228), t2), i(r2(1491), t2), i(r2(8169), t2), i(r2(4016), t2), i(r2(432), t2), i(r2(7992), t2), i(r2(7894), t2), i(r2(6108), t2), i(r2(5278), t2), i(r2(8121), t2), i(r2(5021), t2);
      }, 5642: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 3867: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7135: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7569: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4630: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 1741: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5395: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 9713: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2140: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6397: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4148: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5937: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2135: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 597: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5086: (e2, t2, r2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.PrerecordedTranscriptionResponse = void 0;
        var n2 = r2(5483), i = function() {
          function e3() {
          }
          return e3.prototype.toWebVTT = function(e4) {
            var t3, r3, i2, s;
            if (e4 === void 0 && (e4 = 8), !this.results || !this.results.utterances)
              throw new Error("This function requires a transcript that was generated with the utterances feature.");
            var o = [];
            return o.push("WEBVTT"), o.push(""), o.push("NOTE"), o.push("Transcription provided by Deepgram"), o.push("Request Id: ".concat((t3 = this.metadata) === null || t3 === void 0 ? void 0 : t3.request_id)), o.push("Created: ".concat((r3 = this.metadata) === null || r3 === void 0 ? void 0 : r3.created)), o.push("Duration: ".concat((i2 = this.metadata) === null || i2 === void 0 ? void 0 : i2.duration)), o.push("Channels: ".concat((s = this.metadata) === null || s === void 0 ? void 0 : s.channels)), o.push(""), this.results.utterances.forEach(function(t4) {
              o.push(function(e5, t5) {
                var r4 = function(e6, t6) {
                  for (var r5 = [], n3 = 0; n3 < e6.length; n3 += t6) {
                    var i4 = e6.slice(n3, n3 + t6);
                    r5.push(i4);
                  }
                  return r5;
                }(e5.words, t5), i3 = [];
                return r4.forEach(function(e6) {
                  var t6 = e6[0], r5 = e6[e6.length - 1];
                  i3.push("".concat((0, n2.secondsToTimestamp)(t6.start), " --> ").concat((0, n2.secondsToTimestamp)(r5.end))), i3.push(e6.map(function(e7) {
                    var t7;
                    return (t7 = e7.punctuated_word) !== null && t7 !== void 0 ? t7 : e7.word;
                  }).join(" ")), i3.push("");
                }), i3.join("\n");
              }(t4, e4));
            }), o.join("\n");
          }, e3.prototype.toSRT = function(e4) {
            if (e4 === void 0 && (e4 = 8), !this.results || !this.results.utterances)
              throw new Error("This function requires a transcript that was generated with the utterances feature.");
            var t3 = [], r3 = 1;
            return this.results.utterances.forEach(function(i2) {
              t3.push(function(e5, t4) {
                var i3 = function(e6, t5) {
                  for (var r4 = [], n3 = 0; n3 < e6.length; n3 += t5) {
                    var i4 = e6.slice(n3, n3 + t5);
                    r4.push(i4);
                  }
                  return r4;
                }(e5.words, t4), s = [];
                return i3.forEach(function(e6) {
                  var t5 = e6[0], i4 = e6[e6.length - 1];
                  s.push((r3++).toString()), s.push("".concat((0, n2.secondsToTimestamp)(t5.start, "HH:mm:ss,SSS"), " --> ").concat((0, n2.secondsToTimestamp)(i4.end, "HH:mm:ss,SSS"))), s.push(e6.map(function(e7) {
                    var t6;
                    return (t6 = e7.punctuated_word) !== null && t6 !== void 0 ? t6 : e7.word;
                  }).join(" ")), s.push("");
                }), s.join("\n");
              }(i2, e4));
            }), t3.join("\n");
          }, e3;
        }();
        t2.PrerecordedTranscriptionResponse = i;
      }, 6339: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 838: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4439: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2678: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 9266: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7845: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5935: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 1562: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6536: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 393: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 3249: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2401: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2e3: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4019: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 9070: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 2862: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5228: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 1491: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 8169: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 4016: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 432: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7992: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 7894: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 6108: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5278: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 8121: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true });
      }, 5321: function(e2, t2, r2) {
        "use strict";
        var n2 = this && this.__assign || function() {
          return n2 = Object.assign || function(e3) {
            for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
              for (var i2 in t3 = arguments[r3])
                Object.prototype.hasOwnProperty.call(t3, i2) && (e3[i2] = t3[i2]);
            return e3;
          }, n2.apply(this, arguments);
        }, i = this && this.__awaiter || function(e3, t3, r3, n3) {
          return new (r3 || (r3 = Promise))(function(i2, s2) {
            function o2(e4) {
              try {
                c2(n3.next(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function a2(e4) {
              try {
                c2(n3.throw(e4));
              } catch (e5) {
                s2(e5);
              }
            }
            function c2(e4) {
              var t4;
              e4.done ? i2(e4.value) : (t4 = e4.value, t4 instanceof r3 ? t4 : new r3(function(e5) {
                e5(t4);
              })).then(o2, a2);
            }
            c2((n3 = n3.apply(e3, t3 || [])).next());
          });
        }, s = this && this.__generator || function(e3, t3) {
          var r3, n3, i2, s2, o2 = { label: 0, sent: function() {
            if (1 & i2[0])
              throw i2[1];
            return i2[1];
          }, trys: [], ops: [] };
          return s2 = { next: a2(0), throw: a2(1), return: a2(2) }, typeof Symbol == "function" && (s2[Symbol.iterator] = function() {
            return this;
          }), s2;
          function a2(a3) {
            return function(c2) {
              return function(a4) {
                if (r3)
                  throw new TypeError("Generator is already executing.");
                for (; s2 && (s2 = 0, a4[0] && (o2 = 0)), o2; )
                  try {
                    if (r3 = 1, n3 && (i2 = 2 & a4[0] ? n3.return : a4[0] ? n3.throw || ((i2 = n3.return) && i2.call(n3), 0) : n3.next) && !(i2 = i2.call(n3, a4[1])).done)
                      return i2;
                    switch (n3 = 0, i2 && (a4 = [2 & a4[0], i2.value]), a4[0]) {
                      case 0:
                      case 1:
                        i2 = a4;
                        break;
                      case 4:
                        return o2.label++, { value: a4[1], done: false };
                      case 5:
                        o2.label++, n3 = a4[1], a4 = [0];
                        continue;
                      case 7:
                        a4 = o2.ops.pop(), o2.trys.pop();
                        continue;
                      default:
                        if (!((i2 = (i2 = o2.trys).length > 0 && i2[i2.length - 1]) || a4[0] !== 6 && a4[0] !== 2)) {
                          o2 = 0;
                          continue;
                        }
                        if (a4[0] === 3 && (!i2 || a4[1] > i2[0] && a4[1] < i2[3])) {
                          o2.label = a4[1];
                          break;
                        }
                        if (a4[0] === 6 && o2.label < i2[1]) {
                          o2.label = i2[1], i2 = a4;
                          break;
                        }
                        if (i2 && o2.label < i2[2]) {
                          o2.label = i2[2], o2.ops.push(a4);
                          break;
                        }
                        i2[2] && o2.ops.pop(), o2.trys.pop();
                        continue;
                    }
                    a4 = t3.call(e3, o2);
                  } catch (e4) {
                    a4 = [6, e4], n3 = 0;
                  } finally {
                    r3 = i2 = 0;
                  }
                if (5 & a4[0])
                  throw a4[1];
                return { value: a4[0] ? a4[1] : void 0, done: true };
              }([a3, c2]);
            };
          }
        }, o = this && this.__importDefault || function(e3) {
          return e3 && e3.__esModule ? e3 : { default: e3 };
        };
        Object.defineProperty(t2, "__esModule", { value: true }), t2.Usage = void 0;
        var a = o(r2(3477)), c = function() {
          function e3(e4, t3, r3, n3) {
            this._credentials = e4, this._apiUrl = t3, this._requireSSL = r3, this._request = n3;
          }
          return e3.prototype.listRequests = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), i(this, void 0, void 0, function() {
              var i2;
              return s(this, function(s2) {
                switch (s2.label) {
                  case 0:
                    return i2 = n2({}, t3), [4, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/requests?").concat(a.default.stringify(i2)))];
                  case 1:
                    return [2, s2.sent()];
                }
              });
            });
          }, e3.prototype.getRequest = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), i(this, void 0, void 0, function() {
              return s(this, function(n3) {
                switch (n3.label) {
                  case 0:
                    return [4, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/requests/").concat(t3))];
                  case 1:
                    return [2, n3.sent()];
                }
              });
            });
          }, e3.prototype.getUsage = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), i(this, void 0, void 0, function() {
              var i2;
              return s(this, function(s2) {
                switch (s2.label) {
                  case 0:
                    return i2 = n2({}, t3), [4, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/usage?").concat(a.default.stringify(i2)))];
                  case 1:
                    return [2, s2.sent()];
                }
              });
            });
          }, e3.prototype.getFields = function(e4, t3, r3) {
            return r3 === void 0 && (r3 = "v1/projects"), i(this, void 0, void 0, function() {
              var i2;
              return s(this, function(s2) {
                switch (s2.label) {
                  case 0:
                    return i2 = n2({}, t3), [4, this._request("GET", this._credentials, this._apiUrl, this._requireSSL, "/".concat(r3, "/").concat(e4, "/usage/fields?").concat(a.default.stringify(i2)))];
                  case 1:
                    return [2, s2.sent()];
                }
              });
            });
          }, e3;
        }();
        t2.Usage = c;
      }, 1408: (e2, t2) => {
        "use strict";
        Object.defineProperty(t2, "__esModule", { value: true }), t2.userAgent = void 0, t2.userAgent = function() {
          var e3 = "@deepgram/sdk/UNKNOWN node/UNKNOWN";
          try {
            e3 = "@deepgram/sdk/".concat("2.3.0", " node/").concat(process.version.replace("v", ""));
          } catch (e4) {
            console.warn("Could not load package details");
          }
          return e3;
        };
      }, 9376: (e2) => {
        "use strict";
        e2.exports = { mask: (e3, t2, r2, n2, i) => {
          for (var s = 0; s < i; s++)
            r2[n2 + s] = e3[s] ^ t2[3 & s];
        }, unmask: (e3, t2) => {
          const r2 = e3.length;
          for (var n2 = 0; n2 < r2; n2++)
            e3[n2] ^= t2[3 & n2];
        } };
      }, 1891: (e2, t2, r2) => {
        "use strict";
        try {
          e2.exports = r2(9516)(__dirname);
        } catch (t3) {
          e2.exports = r2(9376);
        }
      }, 7484: function(e2) {
        e2.exports = function() {
          "use strict";
          var e3 = 6e4, t2 = 36e5, r2 = "millisecond", n2 = "second", i = "minute", s = "hour", o = "day", a = "week", c = "month", u = "quarter", l = "year", h = "date", f = "Invalid Date", d = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, p = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, _ = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(e4) {
            var t3 = ["th", "st", "nd", "rd"], r3 = e4 % 100;
            return "[" + e4 + (t3[(r3 - 20) % 10] || t3[r3] || t3[0]) + "]";
          } }, v = function(e4, t3, r3) {
            var n3 = String(e4);
            return !n3 || n3.length >= t3 ? e4 : "" + Array(t3 + 1 - n3.length).join(r3) + e4;
          }, y = { s: v, z: function(e4) {
            var t3 = -e4.utcOffset(), r3 = Math.abs(t3), n3 = Math.floor(r3 / 60), i2 = r3 % 60;
            return (t3 <= 0 ? "+" : "-") + v(n3, 2, "0") + ":" + v(i2, 2, "0");
          }, m: function e4(t3, r3) {
            if (t3.date() < r3.date())
              return -e4(r3, t3);
            var n3 = 12 * (r3.year() - t3.year()) + (r3.month() - t3.month()), i2 = t3.clone().add(n3, c), s2 = r3 - i2 < 0, o2 = t3.clone().add(n3 + (s2 ? -1 : 1), c);
            return +(-(n3 + (r3 - i2) / (s2 ? i2 - o2 : o2 - i2)) || 0);
          }, a: function(e4) {
            return e4 < 0 ? Math.ceil(e4) || 0 : Math.floor(e4);
          }, p: function(e4) {
            return { M: c, y: l, w: a, d: o, D: h, h: s, m: i, s: n2, ms: r2, Q: u }[e4] || String(e4 || "").toLowerCase().replace(/s$/, "");
          }, u: function(e4) {
            return e4 === void 0;
          } }, b = "en", m = {};
          m[b] = _;
          var g = function(e4) {
            return e4 instanceof x;
          }, S = function e4(t3, r3, n3) {
            var i2;
            if (!t3)
              return b;
            if (typeof t3 == "string") {
              var s2 = t3.toLowerCase();
              m[s2] && (i2 = s2), r3 && (m[s2] = r3, i2 = s2);
              var o2 = t3.split("-");
              if (!i2 && o2.length > 1)
                return e4(o2[0]);
            } else {
              var a2 = t3.name;
              m[a2] = t3, i2 = a2;
            }
            return !n3 && i2 && (b = i2), i2 || !n3 && b;
          }, w = function(e4, t3) {
            if (g(e4))
              return e4.clone();
            var r3 = typeof t3 == "object" ? t3 : {};
            return r3.date = e4, r3.args = arguments, new x(r3);
          }, O = y;
          O.l = S, O.i = g, O.w = function(e4, t3) {
            return w(e4, { locale: t3.$L, utc: t3.$u, x: t3.$x, $offset: t3.$offset });
          };
          var x = function() {
            function _2(e4) {
              this.$L = S(e4.locale, null, true), this.parse(e4);
            }
            var v2 = _2.prototype;
            return v2.parse = function(e4) {
              this.$d = function(e5) {
                var t3 = e5.date, r3 = e5.utc;
                if (t3 === null)
                  return new Date(NaN);
                if (O.u(t3))
                  return new Date();
                if (t3 instanceof Date)
                  return new Date(t3);
                if (typeof t3 == "string" && !/Z$/i.test(t3)) {
                  var n3 = t3.match(d);
                  if (n3) {
                    var i2 = n3[2] - 1 || 0, s2 = (n3[7] || "0").substring(0, 3);
                    return r3 ? new Date(Date.UTC(n3[1], i2, n3[3] || 1, n3[4] || 0, n3[5] || 0, n3[6] || 0, s2)) : new Date(n3[1], i2, n3[3] || 1, n3[4] || 0, n3[5] || 0, n3[6] || 0, s2);
                  }
                }
                return new Date(t3);
              }(e4), this.$x = e4.x || {}, this.init();
            }, v2.init = function() {
              var e4 = this.$d;
              this.$y = e4.getFullYear(), this.$M = e4.getMonth(), this.$D = e4.getDate(), this.$W = e4.getDay(), this.$H = e4.getHours(), this.$m = e4.getMinutes(), this.$s = e4.getSeconds(), this.$ms = e4.getMilliseconds();
            }, v2.$utils = function() {
              return O;
            }, v2.isValid = function() {
              return !(this.$d.toString() === f);
            }, v2.isSame = function(e4, t3) {
              var r3 = w(e4);
              return this.startOf(t3) <= r3 && r3 <= this.endOf(t3);
            }, v2.isAfter = function(e4, t3) {
              return w(e4) < this.startOf(t3);
            }, v2.isBefore = function(e4, t3) {
              return this.endOf(t3) < w(e4);
            }, v2.$g = function(e4, t3, r3) {
              return O.u(e4) ? this[t3] : this.set(r3, e4);
            }, v2.unix = function() {
              return Math.floor(this.valueOf() / 1e3);
            }, v2.valueOf = function() {
              return this.$d.getTime();
            }, v2.startOf = function(e4, t3) {
              var r3 = this, u2 = !!O.u(t3) || t3, f2 = O.p(e4), d2 = function(e5, t4) {
                var n3 = O.w(r3.$u ? Date.UTC(r3.$y, t4, e5) : new Date(r3.$y, t4, e5), r3);
                return u2 ? n3 : n3.endOf(o);
              }, p2 = function(e5, t4) {
                return O.w(r3.toDate()[e5].apply(r3.toDate("s"), (u2 ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(t4)), r3);
              }, _3 = this.$W, v3 = this.$M, y2 = this.$D, b2 = "set" + (this.$u ? "UTC" : "");
              switch (f2) {
                case l:
                  return u2 ? d2(1, 0) : d2(31, 11);
                case c:
                  return u2 ? d2(1, v3) : d2(0, v3 + 1);
                case a:
                  var m2 = this.$locale().weekStart || 0, g2 = (_3 < m2 ? _3 + 7 : _3) - m2;
                  return d2(u2 ? y2 - g2 : y2 + (6 - g2), v3);
                case o:
                case h:
                  return p2(b2 + "Hours", 0);
                case s:
                  return p2(b2 + "Minutes", 1);
                case i:
                  return p2(b2 + "Seconds", 2);
                case n2:
                  return p2(b2 + "Milliseconds", 3);
                default:
                  return this.clone();
              }
            }, v2.endOf = function(e4) {
              return this.startOf(e4, false);
            }, v2.$set = function(e4, t3) {
              var a2, u2 = O.p(e4), f2 = "set" + (this.$u ? "UTC" : ""), d2 = (a2 = {}, a2[o] = f2 + "Date", a2[h] = f2 + "Date", a2[c] = f2 + "Month", a2[l] = f2 + "FullYear", a2[s] = f2 + "Hours", a2[i] = f2 + "Minutes", a2[n2] = f2 + "Seconds", a2[r2] = f2 + "Milliseconds", a2)[u2], p2 = u2 === o ? this.$D + (t3 - this.$W) : t3;
              if (u2 === c || u2 === l) {
                var _3 = this.clone().set(h, 1);
                _3.$d[d2](p2), _3.init(), this.$d = _3.set(h, Math.min(this.$D, _3.daysInMonth())).$d;
              } else
                d2 && this.$d[d2](p2);
              return this.init(), this;
            }, v2.set = function(e4, t3) {
              return this.clone().$set(e4, t3);
            }, v2.get = function(e4) {
              return this[O.p(e4)]();
            }, v2.add = function(r3, u2) {
              var h2, f2 = this;
              r3 = Number(r3);
              var d2 = O.p(u2), p2 = function(e4) {
                var t3 = w(f2);
                return O.w(t3.date(t3.date() + Math.round(e4 * r3)), f2);
              };
              if (d2 === c)
                return this.set(c, this.$M + r3);
              if (d2 === l)
                return this.set(l, this.$y + r3);
              if (d2 === o)
                return p2(1);
              if (d2 === a)
                return p2(7);
              var _3 = (h2 = {}, h2[i] = e3, h2[s] = t2, h2[n2] = 1e3, h2)[d2] || 1, v3 = this.$d.getTime() + r3 * _3;
              return O.w(v3, this);
            }, v2.subtract = function(e4, t3) {
              return this.add(-1 * e4, t3);
            }, v2.format = function(e4) {
              var t3 = this, r3 = this.$locale();
              if (!this.isValid())
                return r3.invalidDate || f;
              var n3 = e4 || "YYYY-MM-DDTHH:mm:ssZ", i2 = O.z(this), s2 = this.$H, o2 = this.$m, a2 = this.$M, c2 = r3.weekdays, u2 = r3.months, l2 = r3.meridiem, h2 = function(e5, r4, i3, s3) {
                return e5 && (e5[r4] || e5(t3, n3)) || i3[r4].slice(0, s3);
              }, d2 = function(e5) {
                return O.s(s2 % 12 || 12, e5, "0");
              }, _3 = l2 || function(e5, t4, r4) {
                var n4 = e5 < 12 ? "AM" : "PM";
                return r4 ? n4.toLowerCase() : n4;
              };
              return n3.replace(p, function(e5, n4) {
                return n4 || function(e6) {
                  switch (e6) {
                    case "YY":
                      return String(t3.$y).slice(-2);
                    case "YYYY":
                      return O.s(t3.$y, 4, "0");
                    case "M":
                      return a2 + 1;
                    case "MM":
                      return O.s(a2 + 1, 2, "0");
                    case "MMM":
                      return h2(r3.monthsShort, a2, u2, 3);
                    case "MMMM":
                      return h2(u2, a2);
                    case "D":
                      return t3.$D;
                    case "DD":
                      return O.s(t3.$D, 2, "0");
                    case "d":
                      return String(t3.$W);
                    case "dd":
                      return h2(r3.weekdaysMin, t3.$W, c2, 2);
                    case "ddd":
                      return h2(r3.weekdaysShort, t3.$W, c2, 3);
                    case "dddd":
                      return c2[t3.$W];
                    case "H":
                      return String(s2);
                    case "HH":
                      return O.s(s2, 2, "0");
                    case "h":
                      return d2(1);
                    case "hh":
                      return d2(2);
                    case "a":
                      return _3(s2, o2, true);
                    case "A":
                      return _3(s2, o2, false);
                    case "m":
                      return String(o2);
                    case "mm":
                      return O.s(o2, 2, "0");
                    case "s":
                      return String(t3.$s);
                    case "ss":
                      return O.s(t3.$s, 2, "0");
                    case "SSS":
                      return O.s(t3.$ms, 3, "0");
                    case "Z":
                      return i2;
                  }
                  return null;
                }(e5) || i2.replace(":", "");
              });
            }, v2.utcOffset = function() {
              return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
            }, v2.diff = function(r3, h2, f2) {
              var d2, p2 = this, _3 = O.p(h2), v3 = w(r3), y2 = (v3.utcOffset() - this.utcOffset()) * e3, b2 = this - v3, m2 = function() {
                return O.m(p2, v3);
              };
              switch (_3) {
                case l:
                  d2 = m2() / 12;
                  break;
                case c:
                  d2 = m2();
                  break;
                case u:
                  d2 = m2() / 3;
                  break;
                case a:
                  d2 = (b2 - y2) / 6048e5;
                  break;
                case o:
                  d2 = (b2 - y2) / 864e5;
                  break;
                case s:
                  d2 = b2 / t2;
                  break;
                case i:
                  d2 = b2 / e3;
                  break;
                case n2:
                  d2 = b2 / 1e3;
                  break;
                default:
                  d2 = b2;
              }
              return f2 ? d2 : O.a(d2);
            }, v2.daysInMonth = function() {
              return this.endOf(c).$D;
            }, v2.$locale = function() {
              return m[this.$L];
            }, v2.locale = function(e4, t3) {
              if (!e4)
                return this.$L;
              var r3 = this.clone(), n3 = S(e4, t3, true);
              return n3 && (r3.$L = n3), r3;
            }, v2.clone = function() {
              return O.w(this.$d, this);
            }, v2.toDate = function() {
              return new Date(this.valueOf());
            }, v2.toJSON = function() {
              return this.isValid() ? this.toISOString() : null;
            }, v2.toISOString = function() {
              return this.$d.toISOString();
            }, v2.toString = function() {
              return this.$d.toUTCString();
            }, _2;
          }(), E = x.prototype;
          return w.prototype = E, [["$ms", r2], ["$s", n2], ["$m", i], ["$H", s], ["$W", o], ["$M", c], ["$y", l], ["$D", h]].forEach(function(e4) {
            E[e4[1]] = function(t3) {
              return this.$g(t3, e4[0], e4[1]);
            };
          }), w.extend = function(e4, t3) {
            return e4.$i || (e4(t3, x, w), e4.$i = true), w;
          }, w.locale = S, w.isDayjs = g, w.unix = function(e4) {
            return w(1e3 * e4);
          }, w.en = m[b], w.Ls = m, w.p = {}, w;
        }();
      }, 178: function(e2) {
        e2.exports = function() {
          "use strict";
          var e3 = "minute", t2 = /[+-]\d\d(?::?\d\d)?/g, r2 = /([+-]|\d\d)/g;
          return function(n2, i, s) {
            var o = i.prototype;
            s.utc = function(e4) {
              return new i({ date: e4, utc: true, args: arguments });
            }, o.utc = function(t3) {
              var r3 = s(this.toDate(), { locale: this.$L, utc: true });
              return t3 ? r3.add(this.utcOffset(), e3) : r3;
            }, o.local = function() {
              return s(this.toDate(), { locale: this.$L, utc: false });
            };
            var a = o.parse;
            o.parse = function(e4) {
              e4.utc && (this.$u = true), this.$utils().u(e4.$offset) || (this.$offset = e4.$offset), a.call(this, e4);
            };
            var c = o.init;
            o.init = function() {
              if (this.$u) {
                var e4 = this.$d;
                this.$y = e4.getUTCFullYear(), this.$M = e4.getUTCMonth(), this.$D = e4.getUTCDate(), this.$W = e4.getUTCDay(), this.$H = e4.getUTCHours(), this.$m = e4.getUTCMinutes(), this.$s = e4.getUTCSeconds(), this.$ms = e4.getUTCMilliseconds();
              } else
                c.call(this);
            };
            var u = o.utcOffset;
            o.utcOffset = function(n3, i2) {
              var s2 = this.$utils().u;
              if (s2(n3))
                return this.$u ? 0 : s2(this.$offset) ? u.call(this) : this.$offset;
              if (typeof n3 == "string" && (n3 = function(e4) {
                e4 === void 0 && (e4 = "");
                var n4 = e4.match(t2);
                if (!n4)
                  return null;
                var i3 = ("" + n4[0]).match(r2) || ["-", 0, 0], s3 = i3[0], o3 = 60 * +i3[1] + +i3[2];
                return o3 === 0 ? 0 : s3 === "+" ? o3 : -o3;
              }(n3), n3 === null))
                return this;
              var o2 = Math.abs(n3) <= 16 ? 60 * n3 : n3, a2 = this;
              if (i2)
                return a2.$offset = o2, a2.$u = n3 === 0, a2;
              if (n3 !== 0) {
                var c2 = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
                (a2 = this.local().add(o2 + c2, e3)).$offset = o2, a2.$x.$localOffset = c2;
              } else
                a2 = this.utc();
              return a2;
            };
            var l = o.format;
            o.format = function(e4) {
              var t3 = e4 || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
              return l.call(this, t3);
            }, o.valueOf = function() {
              var e4 = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
              return this.$d.valueOf() - 6e4 * e4;
            }, o.isUTC = function() {
              return !!this.$u;
            }, o.toISOString = function() {
              return this.toDate().toISOString();
            }, o.toString = function() {
              return this.toDate().toUTCString();
            };
            var h = o.toDate;
            o.toDate = function(e4) {
              return e4 === "s" && this.$offset ? s(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : h.call(this);
            };
            var f = o.diff;
            o.diff = function(e4, t3, r3) {
              if (e4 && this.$u === e4.$u)
                return f.call(this, e4, t3, r3);
              var n3 = this.local(), i2 = s(e4).local();
              return f.call(n3, i2, t3, r3);
            };
          };
        }();
      }, 9516: (e2, t2, r2) => {
        typeof process.addon == "function" ? e2.exports = process.addon.bind(process) : e2.exports = r2(7524);
      }, 7524: (e2, t2, r2) => {
        var n2 = r2(7147), i = r2(1017), s = r2(2037), o = require, a = process.config && process.config.variables || {}, c = !!process.env.PREBUILDS_ONLY, u = process.versions.modules, l = process.versions && process.versions.electron || process.env.ELECTRON_RUN_AS_NODE || typeof window != "undefined" && window.process && window.process.type === "renderer" ? "electron" : process.versions && process.versions.nw ? "node-webkit" : "node", h = process.env.npm_config_arch || s.arch(), f = process.env.npm_config_platform || s.platform(), d = process.env.LIBC || (function(e3) {
          return e3 === "linux" && n2.existsSync("/etc/alpine-release");
        }(f) ? "musl" : "glibc"), p = process.env.ARM_VERSION || (h === "arm64" ? "8" : a.arm_version) || "", _ = (process.versions.uv || "").split(".")[0];
        function v(e3) {
          return o(v.resolve(e3));
        }
        function y(e3) {
          try {
            return n2.readdirSync(e3);
          } catch (e4) {
            return [];
          }
        }
        function b(e3, t3) {
          var r3 = y(e3).filter(t3);
          return r3[0] && i.join(e3, r3[0]);
        }
        function m(e3) {
          return /\.node$/.test(e3);
        }
        function g(e3) {
          var t3 = e3.split("-");
          if (t3.length === 2) {
            var r3 = t3[0], n3 = t3[1].split("+");
            if (r3 && n3.length && n3.every(Boolean))
              return { name: e3, platform: r3, architectures: n3 };
          }
        }
        function S(e3, t3) {
          return function(r3) {
            return r3 != null && r3.platform === e3 && r3.architectures.includes(t3);
          };
        }
        function w(e3, t3) {
          return e3.architectures.length - t3.architectures.length;
        }
        function O(e3) {
          var t3 = e3.split("."), r3 = { file: e3, specificity: 0 };
          if (t3.pop() === "node") {
            for (var n3 = 0; n3 < t3.length; n3++) {
              var i2 = t3[n3];
              if (i2 === "node" || i2 === "electron" || i2 === "node-webkit")
                r3.runtime = i2;
              else if (i2 === "napi")
                r3.napi = true;
              else if (i2.slice(0, 3) === "abi")
                r3.abi = i2.slice(3);
              else if (i2.slice(0, 2) === "uv")
                r3.uv = i2.slice(2);
              else if (i2.slice(0, 4) === "armv")
                r3.armv = i2.slice(4);
              else {
                if (i2 !== "glibc" && i2 !== "musl")
                  continue;
                r3.libc = i2;
              }
              r3.specificity++;
            }
            return r3;
          }
        }
        function x(e3, t3) {
          return function(r3) {
            return !(r3 == null || r3.runtime !== e3 && !function(e4) {
              return e4.runtime === "node" && e4.napi;
            }(r3) || r3.abi !== t3 && !r3.napi || r3.uv && r3.uv !== _ || r3.armv && r3.armv !== p || r3.libc && r3.libc !== d);
          };
        }
        function E(e3) {
          return function(t3, r3) {
            return t3.runtime !== r3.runtime ? t3.runtime === e3 ? -1 : 1 : t3.abi !== r3.abi ? t3.abi ? -1 : 1 : t3.specificity !== r3.specificity ? t3.specificity > r3.specificity ? -1 : 1 : 0;
          };
        }
        e2.exports = v, v.resolve = v.path = function(e3) {
          e3 = i.resolve(e3 || ".");
          try {
            var t3 = o(i.join(e3, "package.json")).name.toUpperCase().replace(/-/g, "_");
            process.env[t3 + "_PREBUILD"] && (e3 = process.env[t3 + "_PREBUILD"]);
          } catch (e4) {
          }
          if (!c) {
            var r3 = b(i.join(e3, "build/Release"), m);
            if (r3)
              return r3;
            var n3 = b(i.join(e3, "build/Debug"), m);
            if (n3)
              return n3;
          }
          var s2 = k(e3);
          if (s2)
            return s2;
          var a2 = k(i.dirname(process.execPath));
          if (a2)
            return a2;
          var v2 = ["platform=" + f, "arch=" + h, "runtime=" + l, "abi=" + u, "uv=" + _, p ? "armv=" + p : "", "libc=" + d, "node=" + process.versions.node, process.versions.electron ? "electron=" + process.versions.electron : "", "webpack=true"].filter(Boolean).join(" ");
          throw new Error("No native build was found for " + v2 + "\n    loaded from: " + e3 + "\n");
          function k(e4) {
            var t4 = y(i.join(e4, "prebuilds")).map(g).filter(S(f, h)).sort(w)[0];
            if (t4) {
              var r4 = i.join(e4, "prebuilds", t4.name), n4 = y(r4).map(O).filter(x(l, u)).sort(E(l))[0];
              return n4 ? i.join(r4, n4.file) : void 0;
            }
          }
        }, v.parseTags = O, v.matchTags = x, v.compareTags = E, v.parseTuple = g, v.matchTuple = S, v.compareTuples = w;
      }, 137: (e2) => {
        "use strict";
        e2.exports = function(e3) {
          const t2 = e3.length;
          let r2 = 0;
          for (; r2 < t2; )
            if ((128 & e3[r2]) == 0)
              r2++;
            else if ((224 & e3[r2]) == 192) {
              if (r2 + 1 === t2 || (192 & e3[r2 + 1]) != 128 || (254 & e3[r2]) == 192)
                return false;
              r2 += 2;
            } else if ((240 & e3[r2]) == 224) {
              if (r2 + 2 >= t2 || (192 & e3[r2 + 1]) != 128 || (192 & e3[r2 + 2]) != 128 || e3[r2] === 224 && (224 & e3[r2 + 1]) == 128 || e3[r2] === 237 && (224 & e3[r2 + 1]) == 160)
                return false;
              r2 += 3;
            } else {
              if ((248 & e3[r2]) != 240)
                return false;
              if (r2 + 3 >= t2 || (192 & e3[r2 + 1]) != 128 || (192 & e3[r2 + 2]) != 128 || (192 & e3[r2 + 3]) != 128 || e3[r2] === 240 && (240 & e3[r2 + 1]) == 128 || e3[r2] === 244 && e3[r2 + 1] > 143 || e3[r2] > 244)
                return false;
              r2 += 4;
            }
          return true;
        };
      }, 311: (e2, t2, r2) => {
        "use strict";
        try {
          e2.exports = r2(9516)(__dirname);
        } catch (t3) {
          e2.exports = r2(137);
        }
      }, 8777: (e2, t2, r2) => {
        "use strict";
        const n2 = r2(8762);
        n2.createWebSocketStream = r2(404), n2.Server = r2(9284), n2.Receiver = r2(2957), n2.Sender = r2(7330), e2.exports = n2;
      }, 977: (e2, t2, r2) => {
        "use strict";
        const { EMPTY_BUFFER: n2 } = r2(1872);
        function i(e3, t3) {
          if (e3.length === 0)
            return n2;
          if (e3.length === 1)
            return e3[0];
          const r3 = Buffer.allocUnsafe(t3);
          let i2 = 0;
          for (let t4 = 0; t4 < e3.length; t4++) {
            const n3 = e3[t4];
            r3.set(n3, i2), i2 += n3.length;
          }
          return i2 < t3 ? r3.slice(0, i2) : r3;
        }
        function s(e3, t3, r3, n3, i2) {
          for (let s2 = 0; s2 < i2; s2++)
            r3[n3 + s2] = e3[s2] ^ t3[3 & s2];
        }
        function o(e3, t3) {
          const r3 = e3.length;
          for (let n3 = 0; n3 < r3; n3++)
            e3[n3] ^= t3[3 & n3];
        }
        function a(e3) {
          return e3.byteLength === e3.buffer.byteLength ? e3.buffer : e3.buffer.slice(e3.byteOffset, e3.byteOffset + e3.byteLength);
        }
        function c(e3) {
          if (c.readOnly = true, Buffer.isBuffer(e3))
            return e3;
          let t3;
          return e3 instanceof ArrayBuffer ? t3 = Buffer.from(e3) : ArrayBuffer.isView(e3) ? t3 = Buffer.from(e3.buffer, e3.byteOffset, e3.byteLength) : (t3 = Buffer.from(e3), c.readOnly = false), t3;
        }
        try {
          const t3 = r2(1891), n3 = t3.BufferUtil || t3;
          e2.exports = { concat: i, mask(e3, t4, r3, i2, o2) {
            o2 < 48 ? s(e3, t4, r3, i2, o2) : n3.mask(e3, t4, r3, i2, o2);
          }, toArrayBuffer: a, toBuffer: c, unmask(e3, t4) {
            e3.length < 32 ? o(e3, t4) : n3.unmask(e3, t4);
          } };
        } catch (t3) {
          e2.exports = { concat: i, mask: s, toArrayBuffer: a, toBuffer: c, unmask: o };
        }
      }, 1872: (e2) => {
        "use strict";
        e2.exports = { BINARY_TYPES: ["nodebuffer", "arraybuffer", "fragments"], GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", kStatusCode: Symbol("status-code"), kWebSocket: Symbol("websocket"), EMPTY_BUFFER: Buffer.alloc(0), NOOP: () => {
        } };
      }, 62: (e2) => {
        "use strict";
        class t2 {
          constructor(e3, t3) {
            this.target = t3, this.type = e3;
          }
        }
        class r2 extends t2 {
          constructor(e3, t3) {
            super("message", t3), this.data = e3;
          }
        }
        class n2 extends t2 {
          constructor(e3, t3, r3) {
            super("close", r3), this.wasClean = r3._closeFrameReceived && r3._closeFrameSent, this.reason = t3, this.code = e3;
          }
        }
        class i extends t2 {
          constructor(e3) {
            super("open", e3);
          }
        }
        class s extends t2 {
          constructor(e3, t3) {
            super("error", t3), this.message = e3.message, this.error = e3;
          }
        }
        const o = { addEventListener(e3, t3, o2) {
          if (typeof t3 != "function")
            return;
          function a(e4) {
            t3.call(this, new r2(e4, this));
          }
          function c(e4, r3) {
            t3.call(this, new n2(e4, r3, this));
          }
          function u(e4) {
            t3.call(this, new s(e4, this));
          }
          function l() {
            t3.call(this, new i(this));
          }
          const h = o2 && o2.once ? "once" : "on";
          e3 === "message" ? (a._listener = t3, this[h](e3, a)) : e3 === "close" ? (c._listener = t3, this[h](e3, c)) : e3 === "error" ? (u._listener = t3, this[h](e3, u)) : e3 === "open" ? (l._listener = t3, this[h](e3, l)) : this[h](e3, t3);
        }, removeEventListener(e3, t3) {
          const r3 = this.listeners(e3);
          for (let n3 = 0; n3 < r3.length; n3++)
            r3[n3] !== t3 && r3[n3]._listener !== t3 || this.removeListener(e3, r3[n3]);
        } };
        e2.exports = o;
      }, 1503: (e2) => {
        "use strict";
        const t2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0];
        function r2(e3, t3, r3) {
          e3[t3] === void 0 ? e3[t3] = [r3] : e3[t3].push(r3);
        }
        e2.exports = { format: function(e3) {
          return Object.keys(e3).map((t3) => {
            let r3 = e3[t3];
            return Array.isArray(r3) || (r3 = [r3]), r3.map((e4) => [t3].concat(Object.keys(e4).map((t4) => {
              let r4 = e4[t4];
              return Array.isArray(r4) || (r4 = [r4]), r4.map((e5) => e5 === true ? t4 : `${t4}=${e5}`).join("; ");
            })).join("; ")).join(", ");
          }).join(", ");
        }, parse: function(e3) {
          const n2 = /* @__PURE__ */ Object.create(null);
          if (e3 === void 0 || e3 === "")
            return n2;
          let i, s, o = /* @__PURE__ */ Object.create(null), a = false, c = false, u = false, l = -1, h = -1, f = 0;
          for (; f < e3.length; f++) {
            const d2 = e3.charCodeAt(f);
            if (i === void 0)
              if (h === -1 && t2[d2] === 1)
                l === -1 && (l = f);
              else if (d2 === 32 || d2 === 9)
                h === -1 && l !== -1 && (h = f);
              else {
                if (d2 !== 59 && d2 !== 44)
                  throw new SyntaxError(`Unexpected character at index ${f}`);
                {
                  if (l === -1)
                    throw new SyntaxError(`Unexpected character at index ${f}`);
                  h === -1 && (h = f);
                  const t3 = e3.slice(l, h);
                  d2 === 44 ? (r2(n2, t3, o), o = /* @__PURE__ */ Object.create(null)) : i = t3, l = h = -1;
                }
              }
            else if (s === void 0)
              if (h === -1 && t2[d2] === 1)
                l === -1 && (l = f);
              else if (d2 === 32 || d2 === 9)
                h === -1 && l !== -1 && (h = f);
              else if (d2 === 59 || d2 === 44) {
                if (l === -1)
                  throw new SyntaxError(`Unexpected character at index ${f}`);
                h === -1 && (h = f), r2(o, e3.slice(l, h), true), d2 === 44 && (r2(n2, i, o), o = /* @__PURE__ */ Object.create(null), i = void 0), l = h = -1;
              } else {
                if (d2 !== 61 || l === -1 || h !== -1)
                  throw new SyntaxError(`Unexpected character at index ${f}`);
                s = e3.slice(l, f), l = h = -1;
              }
            else if (c) {
              if (t2[d2] !== 1)
                throw new SyntaxError(`Unexpected character at index ${f}`);
              l === -1 ? l = f : a || (a = true), c = false;
            } else if (u)
              if (t2[d2] === 1)
                l === -1 && (l = f);
              else if (d2 === 34 && l !== -1)
                u = false, h = f;
              else {
                if (d2 !== 92)
                  throw new SyntaxError(`Unexpected character at index ${f}`);
                c = true;
              }
            else if (d2 === 34 && e3.charCodeAt(f - 1) === 61)
              u = true;
            else if (h === -1 && t2[d2] === 1)
              l === -1 && (l = f);
            else if (l === -1 || d2 !== 32 && d2 !== 9) {
              if (d2 !== 59 && d2 !== 44)
                throw new SyntaxError(`Unexpected character at index ${f}`);
              {
                if (l === -1)
                  throw new SyntaxError(`Unexpected character at index ${f}`);
                h === -1 && (h = f);
                let t3 = e3.slice(l, h);
                a && (t3 = t3.replace(/\\/g, ""), a = false), r2(o, s, t3), d2 === 44 && (r2(n2, i, o), o = /* @__PURE__ */ Object.create(null), i = void 0), s = void 0, l = h = -1;
              }
            } else
              h === -1 && (h = f);
          }
          if (l === -1 || u)
            throw new SyntaxError("Unexpected end of input");
          h === -1 && (h = f);
          const d = e3.slice(l, h);
          return i === void 0 ? r2(n2, d, o) : (s === void 0 ? r2(o, d, true) : r2(o, s, a ? d.replace(/\\/g, "") : d), r2(n2, i, o)), n2;
        } };
      }, 305: (e2) => {
        "use strict";
        const t2 = Symbol("kDone"), r2 = Symbol("kRun");
        e2.exports = class {
          constructor(e3) {
            this[t2] = () => {
              this.pending--, this[r2]();
            }, this.concurrency = e3 || 1 / 0, this.jobs = [], this.pending = 0;
          }
          add(e3) {
            this.jobs.push(e3), this[r2]();
          }
          [r2]() {
            if (this.pending !== this.concurrency && this.jobs.length) {
              const e3 = this.jobs.shift();
              this.pending++, e3(this[t2]);
            }
          }
        };
      }, 5196: (e2, t2, r2) => {
        "use strict";
        const n2 = r2(9796), i = r2(977), s = r2(305), { kStatusCode: o, NOOP: a } = r2(1872), c = Buffer.from([0, 0, 255, 255]), u = Symbol("permessage-deflate"), l = Symbol("total-length"), h = Symbol("callback"), f = Symbol("buffers"), d = Symbol("error");
        let p;
        function _(e3) {
          this[f].push(e3), this[l] += e3.length;
        }
        function v(e3) {
          this[l] += e3.length, this[u]._maxPayload < 1 || this[l] <= this[u]._maxPayload ? this[f].push(e3) : (this[d] = new RangeError("Max payload size exceeded"), this[d].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH", this[d][o] = 1009, this.removeListener("data", v), this.reset());
        }
        function y(e3) {
          this[u]._inflate = null, e3[o] = 1007, this[h](e3);
        }
        e2.exports = class {
          constructor(e3, t3, r3) {
            if (this._maxPayload = 0 | r3, this._options = e3 || {}, this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024, this._isServer = !!t3, this._deflate = null, this._inflate = null, this.params = null, !p) {
              const e4 = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
              p = new s(e4);
            }
          }
          static get extensionName() {
            return "permessage-deflate";
          }
          offer() {
            const e3 = {};
            return this._options.serverNoContextTakeover && (e3.server_no_context_takeover = true), this._options.clientNoContextTakeover && (e3.client_no_context_takeover = true), this._options.serverMaxWindowBits && (e3.server_max_window_bits = this._options.serverMaxWindowBits), this._options.clientMaxWindowBits ? e3.client_max_window_bits = this._options.clientMaxWindowBits : this._options.clientMaxWindowBits == null && (e3.client_max_window_bits = true), e3;
          }
          accept(e3) {
            return e3 = this.normalizeParams(e3), this.params = this._isServer ? this.acceptAsServer(e3) : this.acceptAsClient(e3), this.params;
          }
          cleanup() {
            if (this._inflate && (this._inflate.close(), this._inflate = null), this._deflate) {
              const e3 = this._deflate[h];
              this._deflate.close(), this._deflate = null, e3 && e3(new Error("The deflate stream was closed while data was being processed"));
            }
          }
          acceptAsServer(e3) {
            const t3 = this._options, r3 = e3.find((e4) => !(t3.serverNoContextTakeover === false && e4.server_no_context_takeover || e4.server_max_window_bits && (t3.serverMaxWindowBits === false || typeof t3.serverMaxWindowBits == "number" && t3.serverMaxWindowBits > e4.server_max_window_bits) || typeof t3.clientMaxWindowBits == "number" && !e4.client_max_window_bits));
            if (!r3)
              throw new Error("None of the extension offers can be accepted");
            return t3.serverNoContextTakeover && (r3.server_no_context_takeover = true), t3.clientNoContextTakeover && (r3.client_no_context_takeover = true), typeof t3.serverMaxWindowBits == "number" && (r3.server_max_window_bits = t3.serverMaxWindowBits), typeof t3.clientMaxWindowBits == "number" ? r3.client_max_window_bits = t3.clientMaxWindowBits : r3.client_max_window_bits !== true && t3.clientMaxWindowBits !== false || delete r3.client_max_window_bits, r3;
          }
          acceptAsClient(e3) {
            const t3 = e3[0];
            if (this._options.clientNoContextTakeover === false && t3.client_no_context_takeover)
              throw new Error('Unexpected parameter "client_no_context_takeover"');
            if (t3.client_max_window_bits) {
              if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits == "number" && t3.client_max_window_bits > this._options.clientMaxWindowBits)
                throw new Error('Unexpected or invalid parameter "client_max_window_bits"');
            } else
              typeof this._options.clientMaxWindowBits == "number" && (t3.client_max_window_bits = this._options.clientMaxWindowBits);
            return t3;
          }
          normalizeParams(e3) {
            return e3.forEach((e4) => {
              Object.keys(e4).forEach((t3) => {
                let r3 = e4[t3];
                if (r3.length > 1)
                  throw new Error(`Parameter "${t3}" must have only a single value`);
                if (r3 = r3[0], t3 === "client_max_window_bits") {
                  if (r3 !== true) {
                    const e5 = +r3;
                    if (!Number.isInteger(e5) || e5 < 8 || e5 > 15)
                      throw new TypeError(`Invalid value for parameter "${t3}": ${r3}`);
                    r3 = e5;
                  } else if (!this._isServer)
                    throw new TypeError(`Invalid value for parameter "${t3}": ${r3}`);
                } else if (t3 === "server_max_window_bits") {
                  const e5 = +r3;
                  if (!Number.isInteger(e5) || e5 < 8 || e5 > 15)
                    throw new TypeError(`Invalid value for parameter "${t3}": ${r3}`);
                  r3 = e5;
                } else {
                  if (t3 !== "client_no_context_takeover" && t3 !== "server_no_context_takeover")
                    throw new Error(`Unknown parameter "${t3}"`);
                  if (r3 !== true)
                    throw new TypeError(`Invalid value for parameter "${t3}": ${r3}`);
                }
                e4[t3] = r3;
              });
            }), e3;
          }
          decompress(e3, t3, r3) {
            p.add((n3) => {
              this._decompress(e3, t3, (e4, t4) => {
                n3(), r3(e4, t4);
              });
            });
          }
          compress(e3, t3, r3) {
            p.add((n3) => {
              this._compress(e3, t3, (e4, t4) => {
                n3(), r3(e4, t4);
              });
            });
          }
          _decompress(e3, t3, r3) {
            const s2 = this._isServer ? "client" : "server";
            if (!this._inflate) {
              const e4 = `${s2}_max_window_bits`, t4 = typeof this.params[e4] != "number" ? n2.Z_DEFAULT_WINDOWBITS : this.params[e4];
              this._inflate = n2.createInflateRaw(__spreadProps(__spreadValues({}, this._options.zlibInflateOptions), { windowBits: t4 })), this._inflate[u] = this, this._inflate[l] = 0, this._inflate[f] = [], this._inflate.on("error", y), this._inflate.on("data", v);
            }
            this._inflate[h] = r3, this._inflate.write(e3), t3 && this._inflate.write(c), this._inflate.flush(() => {
              const e4 = this._inflate[d];
              if (e4)
                return this._inflate.close(), this._inflate = null, void r3(e4);
              const n3 = i.concat(this._inflate[f], this._inflate[l]);
              this._inflate._readableState.endEmitted ? (this._inflate.close(), this._inflate = null) : (this._inflate[l] = 0, this._inflate[f] = [], t3 && this.params[`${s2}_no_context_takeover`] && this._inflate.reset()), r3(null, n3);
            });
          }
          _compress(e3, t3, r3) {
            const s2 = this._isServer ? "server" : "client";
            if (!this._deflate) {
              const e4 = `${s2}_max_window_bits`, t4 = typeof this.params[e4] != "number" ? n2.Z_DEFAULT_WINDOWBITS : this.params[e4];
              this._deflate = n2.createDeflateRaw(__spreadProps(__spreadValues({}, this._options.zlibDeflateOptions), { windowBits: t4 })), this._deflate[l] = 0, this._deflate[f] = [], this._deflate.on("error", a), this._deflate.on("data", _);
            }
            this._deflate[h] = r3, this._deflate.write(e3), this._deflate.flush(n2.Z_SYNC_FLUSH, () => {
              if (!this._deflate)
                return;
              let e4 = i.concat(this._deflate[f], this._deflate[l]);
              t3 && (e4 = e4.slice(0, e4.length - 4)), this._deflate[h] = null, this._deflate[l] = 0, this._deflate[f] = [], t3 && this.params[`${s2}_no_context_takeover`] && this._deflate.reset(), r3(null, e4);
            });
          }
        };
      }, 2957: (e2, t2, r2) => {
        "use strict";
        const { Writable: n2 } = r2(2781), i = r2(5196), { BINARY_TYPES: s, EMPTY_BUFFER: o, kStatusCode: a, kWebSocket: c } = r2(1872), { concat: u, toArrayBuffer: l, unmask: h } = r2(977), { isValidStatusCode: f, isValidUTF8: d } = r2(6746);
        function p(e3, t3, r3, n3, i2) {
          const s2 = new e3(r3 ? `Invalid WebSocket frame: ${t3}` : t3);
          return Error.captureStackTrace(s2, p), s2.code = i2, s2[a] = n3, s2;
        }
        e2.exports = class extends n2 {
          constructor(e3, t3, r3, n3) {
            super(), this._binaryType = e3 || s[0], this[c] = void 0, this._extensions = t3 || {}, this._isServer = !!r3, this._maxPayload = 0 | n3, this._bufferedBytes = 0, this._buffers = [], this._compressed = false, this._payloadLength = 0, this._mask = void 0, this._fragmented = 0, this._masked = false, this._fin = false, this._opcode = 0, this._totalPayloadLength = 0, this._messageLength = 0, this._fragments = [], this._state = 0, this._loop = false;
          }
          _write(e3, t3, r3) {
            if (this._opcode === 8 && this._state == 0)
              return r3();
            this._bufferedBytes += e3.length, this._buffers.push(e3), this.startLoop(r3);
          }
          consume(e3) {
            if (this._bufferedBytes -= e3, e3 === this._buffers[0].length)
              return this._buffers.shift();
            if (e3 < this._buffers[0].length) {
              const t4 = this._buffers[0];
              return this._buffers[0] = t4.slice(e3), t4.slice(0, e3);
            }
            const t3 = Buffer.allocUnsafe(e3);
            do {
              const r3 = this._buffers[0], n3 = t3.length - e3;
              e3 >= r3.length ? t3.set(this._buffers.shift(), n3) : (t3.set(new Uint8Array(r3.buffer, r3.byteOffset, e3), n3), this._buffers[0] = r3.slice(e3)), e3 -= r3.length;
            } while (e3 > 0);
            return t3;
          }
          startLoop(e3) {
            let t3;
            this._loop = true;
            do {
              switch (this._state) {
                case 0:
                  t3 = this.getInfo();
                  break;
                case 1:
                  t3 = this.getPayloadLength16();
                  break;
                case 2:
                  t3 = this.getPayloadLength64();
                  break;
                case 3:
                  this.getMask();
                  break;
                case 4:
                  t3 = this.getData(e3);
                  break;
                default:
                  return void (this._loop = false);
              }
            } while (this._loop);
            e3(t3);
          }
          getInfo() {
            if (this._bufferedBytes < 2)
              return void (this._loop = false);
            const e3 = this.consume(2);
            if ((48 & e3[0]) != 0)
              return this._loop = false, p(RangeError, "RSV2 and RSV3 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_2_3");
            const t3 = (64 & e3[0]) == 64;
            if (t3 && !this._extensions[i.extensionName])
              return this._loop = false, p(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1");
            if (this._fin = (128 & e3[0]) == 128, this._opcode = 15 & e3[0], this._payloadLength = 127 & e3[1], this._opcode === 0) {
              if (t3)
                return this._loop = false, p(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1");
              if (!this._fragmented)
                return this._loop = false, p(RangeError, "invalid opcode 0", true, 1002, "WS_ERR_INVALID_OPCODE");
              this._opcode = this._fragmented;
            } else if (this._opcode === 1 || this._opcode === 2) {
              if (this._fragmented)
                return this._loop = false, p(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE");
              this._compressed = t3;
            } else {
              if (!(this._opcode > 7 && this._opcode < 11))
                return this._loop = false, p(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE");
              if (!this._fin)
                return this._loop = false, p(RangeError, "FIN must be set", true, 1002, "WS_ERR_EXPECTED_FIN");
              if (t3)
                return this._loop = false, p(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1");
              if (this._payloadLength > 125)
                return this._loop = false, p(RangeError, `invalid payload length ${this._payloadLength}`, true, 1002, "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH");
            }
            if (this._fin || this._fragmented || (this._fragmented = this._opcode), this._masked = (128 & e3[1]) == 128, this._isServer) {
              if (!this._masked)
                return this._loop = false, p(RangeError, "MASK must be set", true, 1002, "WS_ERR_EXPECTED_MASK");
            } else if (this._masked)
              return this._loop = false, p(RangeError, "MASK must be clear", true, 1002, "WS_ERR_UNEXPECTED_MASK");
            if (this._payloadLength === 126)
              this._state = 1;
            else {
              if (this._payloadLength !== 127)
                return this.haveLength();
              this._state = 2;
            }
          }
          getPayloadLength16() {
            if (!(this._bufferedBytes < 2))
              return this._payloadLength = this.consume(2).readUInt16BE(0), this.haveLength();
            this._loop = false;
          }
          getPayloadLength64() {
            if (this._bufferedBytes < 8)
              return void (this._loop = false);
            const e3 = this.consume(8), t3 = e3.readUInt32BE(0);
            return t3 > Math.pow(2, 21) - 1 ? (this._loop = false, p(RangeError, "Unsupported WebSocket frame: payload length > 2^53 - 1", false, 1009, "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH")) : (this._payloadLength = t3 * Math.pow(2, 32) + e3.readUInt32BE(4), this.haveLength());
          }
          haveLength() {
            if (this._payloadLength && this._opcode < 8 && (this._totalPayloadLength += this._payloadLength, this._totalPayloadLength > this._maxPayload && this._maxPayload > 0))
              return this._loop = false, p(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH");
            this._masked ? this._state = 3 : this._state = 4;
          }
          getMask() {
            this._bufferedBytes < 4 ? this._loop = false : (this._mask = this.consume(4), this._state = 4);
          }
          getData(e3) {
            let t3 = o;
            if (this._payloadLength) {
              if (this._bufferedBytes < this._payloadLength)
                return void (this._loop = false);
              t3 = this.consume(this._payloadLength), this._masked && h(t3, this._mask);
            }
            return this._opcode > 7 ? this.controlMessage(t3) : this._compressed ? (this._state = 5, void this.decompress(t3, e3)) : (t3.length && (this._messageLength = this._totalPayloadLength, this._fragments.push(t3)), this.dataMessage());
          }
          decompress(e3, t3) {
            this._extensions[i.extensionName].decompress(e3, this._fin, (e4, r3) => {
              if (e4)
                return t3(e4);
              if (r3.length) {
                if (this._messageLength += r3.length, this._messageLength > this._maxPayload && this._maxPayload > 0)
                  return t3(p(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"));
                this._fragments.push(r3);
              }
              const n3 = this.dataMessage();
              if (n3)
                return t3(n3);
              this.startLoop(t3);
            });
          }
          dataMessage() {
            if (this._fin) {
              const e3 = this._messageLength, t3 = this._fragments;
              if (this._totalPayloadLength = 0, this._messageLength = 0, this._fragmented = 0, this._fragments = [], this._opcode === 2) {
                let r3;
                r3 = this._binaryType === "nodebuffer" ? u(t3, e3) : this._binaryType === "arraybuffer" ? l(u(t3, e3)) : t3, this.emit("message", r3);
              } else {
                const r3 = u(t3, e3);
                if (!d(r3))
                  return this._loop = false, p(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8");
                this.emit("message", r3.toString());
              }
            }
            this._state = 0;
          }
          controlMessage(e3) {
            if (this._opcode === 8)
              if (this._loop = false, e3.length === 0)
                this.emit("conclude", 1005, ""), this.end();
              else {
                if (e3.length === 1)
                  return p(RangeError, "invalid payload length 1", true, 1002, "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH");
                {
                  const t3 = e3.readUInt16BE(0);
                  if (!f(t3))
                    return p(RangeError, `invalid status code ${t3}`, true, 1002, "WS_ERR_INVALID_CLOSE_CODE");
                  const r3 = e3.slice(2);
                  if (!d(r3))
                    return p(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8");
                  this.emit("conclude", t3, r3.toString()), this.end();
                }
              }
            else
              this._opcode === 9 ? this.emit("ping", e3) : this.emit("pong", e3);
            this._state = 0;
          }
        };
      }, 7330: (e2, t2, r2) => {
        "use strict";
        r2(1808), r2(4404);
        const { randomFillSync: n2 } = r2(6113), i = r2(5196), { EMPTY_BUFFER: s } = r2(1872), { isValidStatusCode: o } = r2(6746), { mask: a, toBuffer: c } = r2(977), u = Buffer.alloc(4);
        class l {
          constructor(e3, t3) {
            this._extensions = t3 || {}, this._socket = e3, this._firstFragment = true, this._compress = false, this._bufferedBytes = 0, this._deflating = false, this._queue = [];
          }
          static frame(e3, t3) {
            const r3 = t3.mask && t3.readOnly;
            let i2 = t3.mask ? 6 : 2, s2 = e3.length;
            e3.length >= 65536 ? (i2 += 8, s2 = 127) : e3.length > 125 && (i2 += 2, s2 = 126);
            const o2 = Buffer.allocUnsafe(r3 ? e3.length + i2 : i2);
            return o2[0] = t3.fin ? 128 | t3.opcode : t3.opcode, t3.rsv1 && (o2[0] |= 64), o2[1] = s2, s2 === 126 ? o2.writeUInt16BE(e3.length, 2) : s2 === 127 && (o2.writeUInt32BE(0, 2), o2.writeUInt32BE(e3.length, 6)), t3.mask ? (n2(u, 0, 4), o2[1] |= 128, o2[i2 - 4] = u[0], o2[i2 - 3] = u[1], o2[i2 - 2] = u[2], o2[i2 - 1] = u[3], r3 ? (a(e3, u, o2, i2, e3.length), [o2]) : (a(e3, u, e3, 0, e3.length), [o2, e3])) : [o2, e3];
          }
          close(e3, t3, r3, n3) {
            let i2;
            if (e3 === void 0)
              i2 = s;
            else {
              if (typeof e3 != "number" || !o(e3))
                throw new TypeError("First argument must be a valid error code number");
              if (t3 === void 0 || t3 === "")
                i2 = Buffer.allocUnsafe(2), i2.writeUInt16BE(e3, 0);
              else {
                const r4 = Buffer.byteLength(t3);
                if (r4 > 123)
                  throw new RangeError("The message must not be greater than 123 bytes");
                i2 = Buffer.allocUnsafe(2 + r4), i2.writeUInt16BE(e3, 0), i2.write(t3, 2);
              }
            }
            this._deflating ? this.enqueue([this.doClose, i2, r3, n3]) : this.doClose(i2, r3, n3);
          }
          doClose(e3, t3, r3) {
            this.sendFrame(l.frame(e3, { fin: true, rsv1: false, opcode: 8, mask: t3, readOnly: false }), r3);
          }
          ping(e3, t3, r3) {
            const n3 = c(e3);
            if (n3.length > 125)
              throw new RangeError("The data size must not be greater than 125 bytes");
            this._deflating ? this.enqueue([this.doPing, n3, t3, c.readOnly, r3]) : this.doPing(n3, t3, c.readOnly, r3);
          }
          doPing(e3, t3, r3, n3) {
            this.sendFrame(l.frame(e3, { fin: true, rsv1: false, opcode: 9, mask: t3, readOnly: r3 }), n3);
          }
          pong(e3, t3, r3) {
            const n3 = c(e3);
            if (n3.length > 125)
              throw new RangeError("The data size must not be greater than 125 bytes");
            this._deflating ? this.enqueue([this.doPong, n3, t3, c.readOnly, r3]) : this.doPong(n3, t3, c.readOnly, r3);
          }
          doPong(e3, t3, r3, n3) {
            this.sendFrame(l.frame(e3, { fin: true, rsv1: false, opcode: 10, mask: t3, readOnly: r3 }), n3);
          }
          send(e3, t3, r3) {
            const n3 = c(e3), s2 = this._extensions[i.extensionName];
            let o2 = t3.binary ? 2 : 1, a2 = t3.compress;
            if (this._firstFragment ? (this._firstFragment = false, a2 && s2 && (a2 = n3.length >= s2._threshold), this._compress = a2) : (a2 = false, o2 = 0), t3.fin && (this._firstFragment = true), s2) {
              const e4 = { fin: t3.fin, rsv1: a2, opcode: o2, mask: t3.mask, readOnly: c.readOnly };
              this._deflating ? this.enqueue([this.dispatch, n3, this._compress, e4, r3]) : this.dispatch(n3, this._compress, e4, r3);
            } else
              this.sendFrame(l.frame(n3, { fin: t3.fin, rsv1: false, opcode: o2, mask: t3.mask, readOnly: c.readOnly }), r3);
          }
          dispatch(e3, t3, r3, n3) {
            if (!t3)
              return void this.sendFrame(l.frame(e3, r3), n3);
            const s2 = this._extensions[i.extensionName];
            this._bufferedBytes += e3.length, this._deflating = true, s2.compress(e3, r3.fin, (t4, i2) => {
              if (this._socket.destroyed) {
                const e4 = new Error("The socket was closed while data was being compressed");
                typeof n3 == "function" && n3(e4);
                for (let t5 = 0; t5 < this._queue.length; t5++) {
                  const r4 = this._queue[t5][4];
                  typeof r4 == "function" && r4(e4);
                }
              } else
                this._bufferedBytes -= e3.length, this._deflating = false, r3.readOnly = false, this.sendFrame(l.frame(i2, r3), n3), this.dequeue();
            });
          }
          dequeue() {
            for (; !this._deflating && this._queue.length; ) {
              const e3 = this._queue.shift();
              this._bufferedBytes -= e3[1].length, Reflect.apply(e3[0], this, e3.slice(1));
            }
          }
          enqueue(e3) {
            this._bufferedBytes += e3[1].length, this._queue.push(e3);
          }
          sendFrame(e3, t3) {
            e3.length === 2 ? (this._socket.cork(), this._socket.write(e3[0]), this._socket.write(e3[1], t3), this._socket.uncork()) : this._socket.write(e3[0], t3);
          }
        }
        e2.exports = l;
      }, 404: (e2, t2, r2) => {
        "use strict";
        const { Duplex: n2 } = r2(2781);
        function i(e3) {
          e3.emit("close");
        }
        function s() {
          !this.destroyed && this._writableState.finished && this.destroy();
        }
        function o(e3) {
          this.removeListener("error", o), this.destroy(), this.listenerCount("error") === 0 && this.emit("error", e3);
        }
        e2.exports = function(e3, t3) {
          let r3 = true, a = true;
          function c() {
            r3 && e3._socket.resume();
          }
          e3.readyState === e3.CONNECTING ? e3.once("open", function() {
            e3._receiver.removeAllListeners("drain"), e3._receiver.on("drain", c);
          }) : (e3._receiver.removeAllListeners("drain"), e3._receiver.on("drain", c));
          const u = new n2(__spreadProps(__spreadValues({}, t3), { autoDestroy: false, emitClose: false, objectMode: false, writableObjectMode: false }));
          return e3.on("message", function(t4) {
            u.push(t4) || (r3 = false, e3._socket.pause());
          }), e3.once("error", function(e4) {
            u.destroyed || (a = false, u.destroy(e4));
          }), e3.once("close", function() {
            u.destroyed || u.push(null);
          }), u._destroy = function(t4, r4) {
            if (e3.readyState === e3.CLOSED)
              return r4(t4), void process.nextTick(i, u);
            let n3 = false;
            e3.once("error", function(e4) {
              n3 = true, r4(e4);
            }), e3.once("close", function() {
              n3 || r4(t4), process.nextTick(i, u);
            }), a && e3.terminate();
          }, u._final = function(t4) {
            e3.readyState !== e3.CONNECTING ? e3._socket !== null && (e3._socket._writableState.finished ? (t4(), u._readableState.endEmitted && u.destroy()) : (e3._socket.once("finish", function() {
              t4();
            }), e3.close())) : e3.once("open", function() {
              u._final(t4);
            });
          }, u._read = function() {
            e3.readyState !== e3.OPEN && e3.readyState !== e3.CLOSING || r3 || (r3 = true, e3._receiver._writableState.needDrain || e3._socket.resume());
          }, u._write = function(t4, r4, n3) {
            e3.readyState !== e3.CONNECTING ? e3.send(t4, n3) : e3.once("open", function() {
              u._write(t4, r4, n3);
            });
          }, u.on("end", s), u.on("error", o), u;
        };
      }, 6746: (e2, t2, r2) => {
        "use strict";
        function n2(e3) {
          return e3 >= 1e3 && e3 <= 1014 && e3 !== 1004 && e3 !== 1005 && e3 !== 1006 || e3 >= 3e3 && e3 <= 4999;
        }
        function i(e3) {
          const t3 = e3.length;
          let r3 = 0;
          for (; r3 < t3; )
            if ((128 & e3[r3]) == 0)
              r3++;
            else if ((224 & e3[r3]) == 192) {
              if (r3 + 1 === t3 || (192 & e3[r3 + 1]) != 128 || (254 & e3[r3]) == 192)
                return false;
              r3 += 2;
            } else if ((240 & e3[r3]) == 224) {
              if (r3 + 2 >= t3 || (192 & e3[r3 + 1]) != 128 || (192 & e3[r3 + 2]) != 128 || e3[r3] === 224 && (224 & e3[r3 + 1]) == 128 || e3[r3] === 237 && (224 & e3[r3 + 1]) == 160)
                return false;
              r3 += 3;
            } else {
              if ((248 & e3[r3]) != 240)
                return false;
              if (r3 + 3 >= t3 || (192 & e3[r3 + 1]) != 128 || (192 & e3[r3 + 2]) != 128 || (192 & e3[r3 + 3]) != 128 || e3[r3] === 240 && (240 & e3[r3 + 1]) == 128 || e3[r3] === 244 && e3[r3 + 1] > 143 || e3[r3] > 244)
                return false;
              r3 += 4;
            }
          return true;
        }
        try {
          let t3 = r2(311);
          typeof t3 == "object" && (t3 = t3.Validation.isValidUTF8), e2.exports = { isValidStatusCode: n2, isValidUTF8: (e3) => e3.length < 150 ? i(e3) : t3(e3) };
        } catch (t3) {
          e2.exports = { isValidStatusCode: n2, isValidUTF8: i };
        }
      }, 9284: (e2, t2, r2) => {
        "use strict";
        const n2 = r2(2361), i = r2(3685), { createHash: s } = (r2(5687), r2(1808), r2(4404), r2(6113)), o = r2(5196), a = r2(8762), { format: c, parse: u } = r2(1503), { GUID: l, kWebSocket: h } = r2(1872), f = /^[+/0-9A-Za-z]{22}==$/;
        function d(e3) {
          e3._state = 2, e3.emit("close");
        }
        function p() {
          this.destroy();
        }
        function _(e3, t3, r3, n3) {
          e3.writable && (r3 = r3 || i.STATUS_CODES[t3], n3 = __spreadValues({ Connection: "close", "Content-Type": "text/html", "Content-Length": Buffer.byteLength(r3) }, n3), e3.write(`HTTP/1.1 ${t3} ${i.STATUS_CODES[t3]}\r
` + Object.keys(n3).map((e4) => `${e4}: ${n3[e4]}`).join("\r\n") + "\r\n\r\n" + r3)), e3.removeListener("error", p), e3.destroy();
        }
        function v(e3) {
          return e3.trim();
        }
        e2.exports = class extends n2 {
          constructor(e3, t3) {
            if (super(), (e3 = __spreadValues({ maxPayload: 104857600, perMessageDeflate: false, handleProtocols: null, clientTracking: true, verifyClient: null, noServer: false, backlog: null, server: null, host: null, path: null, port: null }, e3)).port == null && !e3.server && !e3.noServer || e3.port != null && (e3.server || e3.noServer) || e3.server && e3.noServer)
              throw new TypeError('One and only one of the "port", "server", or "noServer" options must be specified');
            if (e3.port != null ? (this._server = i.createServer((e4, t4) => {
              const r3 = i.STATUS_CODES[426];
              t4.writeHead(426, { "Content-Length": r3.length, "Content-Type": "text/plain" }), t4.end(r3);
            }), this._server.listen(e3.port, e3.host, e3.backlog, t3)) : e3.server && (this._server = e3.server), this._server) {
              const e4 = this.emit.bind(this, "connection");
              this._removeListeners = function(e5, t4) {
                for (const r3 of Object.keys(t4))
                  e5.on(r3, t4[r3]);
                return function() {
                  for (const r3 of Object.keys(t4))
                    e5.removeListener(r3, t4[r3]);
                };
              }(this._server, { listening: this.emit.bind(this, "listening"), error: this.emit.bind(this, "error"), upgrade: (t4, r3, n3) => {
                this.handleUpgrade(t4, r3, n3, e4);
              } });
            }
            e3.perMessageDeflate === true && (e3.perMessageDeflate = {}), e3.clientTracking && (this.clients = /* @__PURE__ */ new Set()), this.options = e3, this._state = 0;
          }
          address() {
            if (this.options.noServer)
              throw new Error('The server is operating in "noServer" mode');
            return this._server ? this._server.address() : null;
          }
          close(e3) {
            if (e3 && this.once("close", e3), this._state === 2)
              return void process.nextTick(d, this);
            if (this._state === 1)
              return;
            if (this._state = 1, this.clients)
              for (const e4 of this.clients)
                e4.terminate();
            const t3 = this._server;
            t3 && (this._removeListeners(), this._removeListeners = this._server = null, this.options.port != null) ? t3.close(d.bind(void 0, this)) : process.nextTick(d, this);
          }
          shouldHandle(e3) {
            if (this.options.path) {
              const t3 = e3.url.indexOf("?");
              if ((t3 !== -1 ? e3.url.slice(0, t3) : e3.url) !== this.options.path)
                return false;
            }
            return true;
          }
          handleUpgrade(e3, t3, r3, n3) {
            t3.on("error", p);
            const i2 = e3.headers["sec-websocket-key"] !== void 0 && e3.headers["sec-websocket-key"].trim(), s2 = +e3.headers["sec-websocket-version"], a2 = {};
            if (e3.method !== "GET" || e3.headers.upgrade.toLowerCase() !== "websocket" || !i2 || !f.test(i2) || s2 !== 8 && s2 !== 13 || !this.shouldHandle(e3))
              return _(t3, 400);
            if (this.options.perMessageDeflate) {
              const r4 = new o(this.options.perMessageDeflate, true, this.options.maxPayload);
              try {
                const t4 = u(e3.headers["sec-websocket-extensions"]);
                t4[o.extensionName] && (r4.accept(t4[o.extensionName]), a2[o.extensionName] = r4);
              } catch (e4) {
                return _(t3, 400);
              }
            }
            if (this.options.verifyClient) {
              const o2 = { origin: e3.headers[s2 === 8 ? "sec-websocket-origin" : "origin"], secure: !(!e3.socket.authorized && !e3.socket.encrypted), req: e3 };
              if (this.options.verifyClient.length === 2)
                return void this.options.verifyClient(o2, (s3, o3, c2, u2) => {
                  if (!s3)
                    return _(t3, o3 || 401, c2, u2);
                  this.completeUpgrade(i2, a2, e3, t3, r3, n3);
                });
              if (!this.options.verifyClient(o2))
                return _(t3, 401);
            }
            this.completeUpgrade(i2, a2, e3, t3, r3, n3);
          }
          completeUpgrade(e3, t3, r3, n3, i2, u2) {
            if (!n3.readable || !n3.writable)
              return n3.destroy();
            if (n3[h])
              throw new Error("server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration");
            if (this._state > 0)
              return _(n3, 503);
            const f2 = ["HTTP/1.1 101 Switching Protocols", "Upgrade: websocket", "Connection: Upgrade", `Sec-WebSocket-Accept: ${s("sha1").update(e3 + l).digest("base64")}`], d2 = new a(null);
            let y = r3.headers["sec-websocket-protocol"];
            if (y && (y = y.split(",").map(v), y = this.options.handleProtocols ? this.options.handleProtocols(y, r3) : y[0], y && (f2.push(`Sec-WebSocket-Protocol: ${y}`), d2._protocol = y)), t3[o.extensionName]) {
              const e4 = t3[o.extensionName].params, r4 = c({ [o.extensionName]: [e4] });
              f2.push(`Sec-WebSocket-Extensions: ${r4}`), d2._extensions = t3;
            }
            this.emit("headers", f2, r3), n3.write(f2.concat("\r\n").join("\r\n")), n3.removeListener("error", p), d2.setSocket(n3, i2, this.options.maxPayload), this.clients && (this.clients.add(d2), d2.on("close", () => this.clients.delete(d2))), u2(d2, r3);
          }
        };
      }, 8762: (e2, t2, r2) => {
        "use strict";
        const n2 = r2(2361), i = r2(5687), s = r2(3685), o = r2(1808), a = r2(4404), { randomBytes: c, createHash: u } = r2(6113), { Readable: l } = r2(2781), { URL: h } = r2(7310), f = r2(5196), d = r2(2957), p = r2(7330), { BINARY_TYPES: _, EMPTY_BUFFER: v, GUID: y, kStatusCode: b, kWebSocket: m, NOOP: g } = r2(1872), { addEventListener: S, removeEventListener: w } = r2(62), { format: O, parse: x } = r2(1503), { toBuffer: E } = r2(977), k = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"], P = [8, 13];
        class T extends n2 {
          constructor(e3, t3, r3) {
            super(), this._binaryType = _[0], this._closeCode = 1006, this._closeFrameReceived = false, this._closeFrameSent = false, this._closeMessage = "", this._closeTimer = null, this._extensions = {}, this._protocol = "", this._readyState = T.CONNECTING, this._receiver = null, this._sender = null, this._socket = null, e3 !== null ? (this._bufferedAmount = 0, this._isServer = false, this._redirects = 0, Array.isArray(t3) ? t3 = t3.join(", ") : typeof t3 == "object" && t3 !== null && (r3 = t3, t3 = void 0), M(this, e3, t3, r3)) : this._isServer = true;
          }
          get binaryType() {
            return this._binaryType;
          }
          set binaryType(e3) {
            _.includes(e3) && (this._binaryType = e3, this._receiver && (this._receiver._binaryType = e3));
          }
          get bufferedAmount() {
            return this._socket ? this._socket._writableState.length + this._sender._bufferedBytes : this._bufferedAmount;
          }
          get extensions() {
            return Object.keys(this._extensions).join();
          }
          get onclose() {
          }
          set onclose(e3) {
          }
          get onerror() {
          }
          set onerror(e3) {
          }
          get onopen() {
          }
          set onopen(e3) {
          }
          get onmessage() {
          }
          set onmessage(e3) {
          }
          get protocol() {
            return this._protocol;
          }
          get readyState() {
            return this._readyState;
          }
          get url() {
            return this._url;
          }
          setSocket(e3, t3, r3) {
            const n3 = new d(this.binaryType, this._extensions, this._isServer, r3);
            this._sender = new p(e3, this._extensions), this._receiver = n3, this._socket = e3, n3[m] = this, e3[m] = this, n3.on("conclude", D), n3.on("drain", U), n3.on("error", q), n3.on("message", I), n3.on("ping", B), n3.on("pong", A), e3.setTimeout(0), e3.setNoDelay(), t3.length > 0 && e3.unshift(t3), e3.on("close", G), e3.on("data", F), e3.on("end", H), e3.on("error", V), this._readyState = T.OPEN, this.emit("open");
          }
          emitClose() {
            if (!this._socket)
              return this._readyState = T.CLOSED, void this.emit("close", this._closeCode, this._closeMessage);
            this._extensions[f.extensionName] && this._extensions[f.extensionName].cleanup(), this._receiver.removeAllListeners(), this._readyState = T.CLOSED, this.emit("close", this._closeCode, this._closeMessage);
          }
          close(e3, t3) {
            if (this.readyState !== T.CLOSED) {
              if (this.readyState === T.CONNECTING) {
                const e4 = "WebSocket was closed before the connection was established";
                return N(this, this._req, e4);
              }
              this.readyState !== T.CLOSING ? (this._readyState = T.CLOSING, this._sender.close(e3, t3, !this._isServer, (e4) => {
                e4 || (this._closeFrameSent = true, (this._closeFrameReceived || this._receiver._writableState.errorEmitted) && this._socket.end());
              }), this._closeTimer = setTimeout(this._socket.destroy.bind(this._socket), 3e4)) : this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted) && this._socket.end();
            }
          }
          ping(e3, t3, r3) {
            if (this.readyState === T.CONNECTING)
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            typeof e3 == "function" ? (r3 = e3, e3 = t3 = void 0) : typeof t3 == "function" && (r3 = t3, t3 = void 0), typeof e3 == "number" && (e3 = e3.toString()), this.readyState === T.OPEN ? (t3 === void 0 && (t3 = !this._isServer), this._sender.ping(e3 || v, t3, r3)) : $(this, e3, r3);
          }
          pong(e3, t3, r3) {
            if (this.readyState === T.CONNECTING)
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            typeof e3 == "function" ? (r3 = e3, e3 = t3 = void 0) : typeof t3 == "function" && (r3 = t3, t3 = void 0), typeof e3 == "number" && (e3 = e3.toString()), this.readyState === T.OPEN ? (t3 === void 0 && (t3 = !this._isServer), this._sender.pong(e3 || v, t3, r3)) : $(this, e3, r3);
          }
          send(e3, t3, r3) {
            if (this.readyState === T.CONNECTING)
              throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
            if (typeof t3 == "function" && (r3 = t3, t3 = {}), typeof e3 == "number" && (e3 = e3.toString()), this.readyState !== T.OPEN)
              return void $(this, e3, r3);
            const n3 = __spreadValues({ binary: typeof e3 != "string", mask: !this._isServer, compress: true, fin: true }, t3);
            this._extensions[f.extensionName] || (n3.compress = false), this._sender.send(e3 || v, n3, r3);
          }
          terminate() {
            if (this.readyState !== T.CLOSED) {
              if (this.readyState === T.CONNECTING) {
                const e3 = "WebSocket was closed before the connection was established";
                return N(this, this._req, e3);
              }
              this._socket && (this._readyState = T.CLOSING, this._socket.destroy());
            }
          }
        }
        function M(e3, t3, r3, n3) {
          const o2 = __spreadProps(__spreadValues({ protocolVersion: P[1], maxPayload: 104857600, perMessageDeflate: true, followRedirects: false, maxRedirects: 10 }, n3), { createConnection: void 0, socketPath: void 0, hostname: void 0, protocol: void 0, timeout: void 0, method: void 0, host: void 0, path: void 0, port: void 0 });
          if (!P.includes(o2.protocolVersion))
            throw new RangeError(`Unsupported protocol version: ${o2.protocolVersion} (supported versions: ${P.join(", ")})`);
          let a2;
          t3 instanceof h ? (a2 = t3, e3._url = t3.href) : (a2 = new h(t3), e3._url = t3);
          const l2 = a2.protocol === "ws+unix:";
          if (!(a2.host || l2 && a2.pathname)) {
            const t4 = new Error(`Invalid URL: ${e3.url}`);
            if (e3._redirects === 0)
              throw t4;
            return void L(e3, t4);
          }
          const d2 = a2.protocol === "wss:" || a2.protocol === "https:", p2 = d2 ? 443 : 80, _2 = c(16).toString("base64"), v2 = d2 ? i.get : s.get;
          let b2;
          if (o2.createConnection = d2 ? C : j, o2.defaultPort = o2.defaultPort || p2, o2.port = a2.port || p2, o2.host = a2.hostname.startsWith("[") ? a2.hostname.slice(1, -1) : a2.hostname, o2.headers = __spreadValues({ "Sec-WebSocket-Version": o2.protocolVersion, "Sec-WebSocket-Key": _2, Connection: "Upgrade", Upgrade: "websocket" }, o2.headers), o2.path = a2.pathname + a2.search, o2.timeout = o2.handshakeTimeout, o2.perMessageDeflate && (b2 = new f(o2.perMessageDeflate !== true ? o2.perMessageDeflate : {}, false, o2.maxPayload), o2.headers["Sec-WebSocket-Extensions"] = O({ [f.extensionName]: b2.offer() })), r3 && (o2.headers["Sec-WebSocket-Protocol"] = r3), o2.origin && (o2.protocolVersion < 13 ? o2.headers["Sec-WebSocket-Origin"] = o2.origin : o2.headers.Origin = o2.origin), (a2.username || a2.password) && (o2.auth = `${a2.username}:${a2.password}`), l2) {
            const e4 = o2.path.split(":");
            o2.socketPath = e4[0], o2.path = e4[1];
          }
          if (o2.followRedirects) {
            if (e3._redirects === 0) {
              e3._originalUnixSocket = l2, e3._originalSecure = d2, e3._originalHostOrSocketPath = l2 ? o2.socketPath : a2.host;
              const t4 = n3 && n3.headers;
              if (n3 = __spreadProps(__spreadValues({}, n3), { headers: {} }), t4)
                for (const [e4, r4] of Object.entries(t4))
                  n3.headers[e4.toLowerCase()] = r4;
            } else {
              const t4 = l2 ? !!e3._originalUnixSocket && o2.socketPath === e3._originalHostOrSocketPath : !e3._originalUnixSocket && a2.host === e3._originalHostOrSocketPath;
              (!t4 || e3._originalSecure && !d2) && (delete o2.headers.authorization, delete o2.headers.cookie, t4 || delete o2.headers.host, o2.auth = void 0);
            }
            o2.auth && !n3.headers.authorization && (n3.headers.authorization = "Basic " + Buffer.from(o2.auth).toString("base64"));
          }
          let m2 = e3._req = v2(o2);
          o2.timeout && m2.on("timeout", () => {
            N(e3, m2, "Opening handshake has timed out");
          }), m2.on("error", (t4) => {
            m2 === null || m2.aborted || (m2 = e3._req = null, L(e3, t4));
          }), m2.on("response", (i2) => {
            const s2 = i2.headers.location, a3 = i2.statusCode;
            if (s2 && o2.followRedirects && a3 >= 300 && a3 < 400) {
              if (++e3._redirects > o2.maxRedirects)
                return void N(e3, m2, "Maximum redirects exceeded");
              let i3;
              m2.abort();
              try {
                i3 = new h(s2, t3);
              } catch (t4) {
                return void L(e3, t4);
              }
              M(e3, i3, r3, n3);
            } else
              e3.emit("unexpected-response", m2, i2) || N(e3, m2, `Unexpected server response: ${i2.statusCode}`);
          }), m2.on("upgrade", (t4, n4, i2) => {
            if (e3.emit("upgrade", t4), e3.readyState !== T.CONNECTING)
              return;
            if (m2 = e3._req = null, t4.headers.upgrade.toLowerCase() !== "websocket")
              return void N(e3, n4, "Invalid Upgrade header");
            const s2 = u("sha1").update(_2 + y).digest("base64");
            if (t4.headers["sec-websocket-accept"] !== s2)
              return void N(e3, n4, "Invalid Sec-WebSocket-Accept header");
            const a3 = t4.headers["sec-websocket-protocol"], c2 = (r3 || "").split(/, */);
            let l3;
            if (!r3 && a3 ? l3 = "Server sent a subprotocol but none was requested" : r3 && !a3 ? l3 = "Server sent no subprotocol" : a3 && !c2.includes(a3) && (l3 = "Server sent an invalid subprotocol"), l3)
              return void N(e3, n4, l3);
            a3 && (e3._protocol = a3);
            const h2 = t4.headers["sec-websocket-extensions"];
            if (h2 !== void 0) {
              if (!b2)
                return void N(e3, n4, "Server sent a Sec-WebSocket-Extensions header but no extension was requested");
              let t5;
              try {
                t5 = x(h2);
              } catch (t6) {
                return void N(e3, n4, "Invalid Sec-WebSocket-Extensions header");
              }
              const r4 = Object.keys(t5);
              if (r4.length) {
                if (r4.length !== 1 || r4[0] !== f.extensionName)
                  return void N(e3, n4, "Server indicated an extension that was not requested");
                try {
                  b2.accept(t5[f.extensionName]);
                } catch (t6) {
                  return void N(e3, n4, "Invalid Sec-WebSocket-Extensions header");
                }
                e3._extensions[f.extensionName] = b2;
              }
            }
            e3.setSocket(n4, i2, o2.maxPayload);
          });
        }
        function L(e3, t3) {
          e3._readyState = T.CLOSING, e3.emit("error", t3), e3.emitClose();
        }
        function j(e3) {
          return e3.path = e3.socketPath, o.connect(e3);
        }
        function C(e3) {
          return e3.path = void 0, e3.servername || e3.servername === "" || (e3.servername = o.isIP(e3.host) ? "" : e3.host), a.connect(e3);
        }
        function N(e3, t3, r3) {
          e3._readyState = T.CLOSING;
          const n3 = new Error(r3);
          Error.captureStackTrace(n3, N), t3.setHeader ? (t3.abort(), t3.socket && !t3.socket.destroyed && t3.socket.destroy(), t3.once("abort", e3.emitClose.bind(e3)), e3.emit("error", n3)) : (t3.destroy(n3), t3.once("error", e3.emit.bind(e3, "error")), t3.once("close", e3.emitClose.bind(e3)));
        }
        function $(e3, t3, r3) {
          if (t3) {
            const r4 = E(t3).length;
            e3._socket ? e3._sender._bufferedBytes += r4 : e3._bufferedAmount += r4;
          }
          r3 && r3(new Error(`WebSocket is not open: readyState ${e3.readyState} (${k[e3.readyState]})`));
        }
        function D(e3, t3) {
          const r3 = this[m];
          r3._closeFrameReceived = true, r3._closeMessage = t3, r3._closeCode = e3, r3._socket[m] !== void 0 && (r3._socket.removeListener("data", F), process.nextTick(W, r3._socket), e3 === 1005 ? r3.close() : r3.close(e3, t3));
        }
        function U() {
          this[m]._socket.resume();
        }
        function q(e3) {
          const t3 = this[m];
          t3._socket[m] !== void 0 && (t3._socket.removeListener("data", F), process.nextTick(W, t3._socket), t3.close(e3[b])), t3.emit("error", e3);
        }
        function R() {
          this[m].emitClose();
        }
        function I(e3) {
          this[m].emit("message", e3);
        }
        function B(e3) {
          const t3 = this[m];
          t3.pong(e3, !t3._isServer, g), t3.emit("ping", e3);
        }
        function A(e3) {
          this[m].emit("pong", e3);
        }
        function W(e3) {
          e3.resume();
        }
        function G() {
          const e3 = this[m];
          let t3;
          this.removeListener("close", G), this.removeListener("data", F), this.removeListener("end", H), e3._readyState = T.CLOSING, this._readableState.endEmitted || e3._closeFrameReceived || e3._receiver._writableState.errorEmitted || (t3 = e3._socket.read()) === null || e3._receiver.write(t3), e3._receiver.end(), this[m] = void 0, clearTimeout(e3._closeTimer), e3._receiver._writableState.finished || e3._receiver._writableState.errorEmitted ? e3.emitClose() : (e3._receiver.on("error", R), e3._receiver.on("finish", R));
        }
        function F(e3) {
          this[m]._receiver.write(e3) || this.pause();
        }
        function H() {
          const e3 = this[m];
          e3._readyState = T.CLOSING, e3._receiver.end(), this.end();
        }
        function V() {
          const e3 = this[m];
          this.removeListener("error", V), this.on("error", g), e3 && (e3._readyState = T.CLOSING, this.destroy());
        }
        Object.defineProperty(T, "CONNECTING", { enumerable: true, value: k.indexOf("CONNECTING") }), Object.defineProperty(T.prototype, "CONNECTING", { enumerable: true, value: k.indexOf("CONNECTING") }), Object.defineProperty(T, "OPEN", { enumerable: true, value: k.indexOf("OPEN") }), Object.defineProperty(T.prototype, "OPEN", { enumerable: true, value: k.indexOf("OPEN") }), Object.defineProperty(T, "CLOSING", { enumerable: true, value: k.indexOf("CLOSING") }), Object.defineProperty(T.prototype, "CLOSING", { enumerable: true, value: k.indexOf("CLOSING") }), Object.defineProperty(T, "CLOSED", { enumerable: true, value: k.indexOf("CLOSED") }), Object.defineProperty(T.prototype, "CLOSED", { enumerable: true, value: k.indexOf("CLOSED") }), ["binaryType", "bufferedAmount", "extensions", "protocol", "readyState", "url"].forEach((e3) => {
          Object.defineProperty(T.prototype, e3, { enumerable: true });
        }), ["open", "error", "close", "message"].forEach((e3) => {
          Object.defineProperty(T.prototype, `on${e3}`, { enumerable: true, get() {
            const t3 = this.listeners(e3);
            for (let e4 = 0; e4 < t3.length; e4++)
              if (t3[e4]._listener)
                return t3[e4]._listener;
          }, set(t3) {
            const r3 = this.listeners(e3);
            for (let t4 = 0; t4 < r3.length; t4++)
              r3[t4]._listener && this.removeListener(e3, r3[t4]);
            this.addEventListener(e3, t3);
          } });
        }), T.prototype.addEventListener = S, T.prototype.removeEventListener = w, e2.exports = T;
      }, 6113: (e2) => {
        "use strict";
        e2.exports = require("crypto");
      }, 2361: (e2) => {
        "use strict";
        e2.exports = require("events");
      }, 7147: (e2) => {
        "use strict";
        e2.exports = require("fs");
      }, 3685: (e2) => {
        "use strict";
        e2.exports = require("http");
      }, 5687: (e2) => {
        "use strict";
        e2.exports = require("https");
      }, 1808: (e2) => {
        "use strict";
        e2.exports = require("net");
      }, 2037: (e2) => {
        "use strict";
        e2.exports = require("os");
      }, 1017: (e2) => {
        "use strict";
        e2.exports = require("path");
      }, 3477: (e2) => {
        "use strict";
        e2.exports = require("querystring");
      }, 2781: (e2) => {
        "use strict";
        e2.exports = require("stream");
      }, 4404: (e2) => {
        "use strict";
        e2.exports = require("tls");
      }, 7310: (e2) => {
        "use strict";
        e2.exports = require("url");
      }, 9796: (e2) => {
        "use strict";
        e2.exports = require("zlib");
      } }, t = {};
      function r(n2) {
        var i = t[n2];
        if (i !== void 0)
          return i.exports;
        var s = t[n2] = { exports: {} };
        return e[n2].call(s.exports, s, s.exports, r), s.exports;
      }
      var n = {};
      return (() => {
        "use strict";
        var e2 = n;
        Object.defineProperty(e2, "__esModule", { value: true }), e2.Deepgram = void 0;
        var t2 = r(6092), i = r(9292), s = r(319), o = r(487), a = r(5321), c = r(8949), u = r(6359), l = r(5343), h = r(3647), f = r(5483), d = r(1098);
        e2.Deepgram = function(e3, r2, n2) {
          this._apiKey = e3, this._apiUrl = r2 != null ? r2 : t2.DefaultOptions.apiUrl, this._requireSSL = n2 != null ? n2 : t2.DefaultOptions.requireSSL, (0, f.validateOptions)(this._apiKey, this._apiUrl), this.keys = new i.Keys(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.projects = new s.Projects(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.transcription = new o.Transcriber(this._apiKey, this._apiUrl, this._requireSSL), this.usage = new a.Usage(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.members = new c.Members(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.invitation = new u.Invitation(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.billing = new l.Billing(this._apiKey, this._apiUrl, this._requireSSL, d._request), this.scopes = new h.Scopes(this._apiKey, this._apiUrl, this._requireSSL, d._request);
        };
      })(), n;
    })());
  }
});

// netlify/functions/deepgram_token/node_modules/dotenv/package.json
var require_package = __commonJS({
  "netlify/functions/deepgram_token/node_modules/dotenv/package.json"(exports2, module2) {
    module2.exports = {
      name: "dotenv",
      version: "16.3.1",
      description: "Loads environment variables from .env file",
      main: "lib/main.js",
      types: "lib/main.d.ts",
      exports: {
        ".": {
          types: "./lib/main.d.ts",
          require: "./lib/main.js",
          default: "./lib/main.js"
        },
        "./config": "./config.js",
        "./config.js": "./config.js",
        "./lib/env-options": "./lib/env-options.js",
        "./lib/env-options.js": "./lib/env-options.js",
        "./lib/cli-options": "./lib/cli-options.js",
        "./lib/cli-options.js": "./lib/cli-options.js",
        "./package.json": "./package.json"
      },
      scripts: {
        "dts-check": "tsc --project tests/types/tsconfig.json",
        lint: "standard",
        "lint-readme": "standard-markdown",
        pretest: "npm run lint && npm run dts-check",
        test: "tap tests/*.js --100 -Rspec",
        prerelease: "npm test",
        release: "standard-version"
      },
      repository: {
        type: "git",
        url: "git://github.com/motdotla/dotenv.git"
      },
      funding: "https://github.com/motdotla/dotenv?sponsor=1",
      keywords: [
        "dotenv",
        "env",
        ".env",
        "environment",
        "variables",
        "config",
        "settings"
      ],
      readmeFilename: "README.md",
      license: "BSD-2-Clause",
      devDependencies: {
        "@definitelytyped/dtslint": "^0.0.133",
        "@types/node": "^18.11.3",
        decache: "^4.6.1",
        sinon: "^14.0.1",
        standard: "^17.0.0",
        "standard-markdown": "^7.1.0",
        "standard-version": "^9.5.0",
        tap: "^16.3.0",
        tar: "^6.1.11",
        typescript: "^4.8.4"
      },
      engines: {
        node: ">=12"
      },
      browser: {
        fs: false
      }
    };
  }
});

// netlify/functions/deepgram_token/node_modules/dotenv/lib/main.js
var require_main = __commonJS({
  "netlify/functions/deepgram_token/node_modules/dotenv/lib/main.js"(exports2, module2) {
    var fs = require("fs");
    var path = require("path");
    var os = require("os");
    var crypto = require("crypto");
    var packageJson = require_package();
    var version = packageJson.version;
    var LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
    function parse(src) {
      const obj = {};
      let lines = src.toString();
      lines = lines.replace(/\r\n?/mg, "\n");
      let match;
      while ((match = LINE.exec(lines)) != null) {
        const key = match[1];
        let value = match[2] || "";
        value = value.trim();
        const maybeQuote = value[0];
        value = value.replace(/^(['"`])([\s\S]*)\1$/mg, "$2");
        if (maybeQuote === '"') {
          value = value.replace(/\\n/g, "\n");
          value = value.replace(/\\r/g, "\r");
        }
        obj[key] = value;
      }
      return obj;
    }
    function _parseVault(options) {
      const vaultPath = _vaultPath(options);
      const result = DotenvModule.configDotenv({ path: vaultPath });
      if (!result.parsed) {
        throw new Error(`MISSING_DATA: Cannot parse ${vaultPath} for an unknown reason`);
      }
      const keys = _dotenvKey(options).split(",");
      const length = keys.length;
      let decrypted;
      for (let i = 0; i < length; i++) {
        try {
          const key = keys[i].trim();
          const attrs = _instructions(result, key);
          decrypted = DotenvModule.decrypt(attrs.ciphertext, attrs.key);
          break;
        } catch (error) {
          if (i + 1 >= length) {
            throw error;
          }
        }
      }
      return DotenvModule.parse(decrypted);
    }
    function _log(message) {
      console.log(`[dotenv@${version}][INFO] ${message}`);
    }
    function _warn(message) {
      console.log(`[dotenv@${version}][WARN] ${message}`);
    }
    function _debug(message) {
      console.log(`[dotenv@${version}][DEBUG] ${message}`);
    }
    function _dotenvKey(options) {
      if (options && options.DOTENV_KEY && options.DOTENV_KEY.length > 0) {
        return options.DOTENV_KEY;
      }
      if (process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0) {
        return process.env.DOTENV_KEY;
      }
      return "";
    }
    function _instructions(result, dotenvKey) {
      let uri;
      try {
        uri = new URL(dotenvKey);
      } catch (error) {
        if (error.code === "ERR_INVALID_URL") {
          throw new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenv.org/vault/.env.vault?environment=development");
        }
        throw error;
      }
      const key = uri.password;
      if (!key) {
        throw new Error("INVALID_DOTENV_KEY: Missing key part");
      }
      const environment = uri.searchParams.get("environment");
      if (!environment) {
        throw new Error("INVALID_DOTENV_KEY: Missing environment part");
      }
      const environmentKey = `DOTENV_VAULT_${environment.toUpperCase()}`;
      const ciphertext = result.parsed[environmentKey];
      if (!ciphertext) {
        throw new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${environmentKey} in your .env.vault file.`);
      }
      return { ciphertext, key };
    }
    function _vaultPath(options) {
      let dotenvPath = path.resolve(process.cwd(), ".env");
      if (options && options.path && options.path.length > 0) {
        dotenvPath = options.path;
      }
      return dotenvPath.endsWith(".vault") ? dotenvPath : `${dotenvPath}.vault`;
    }
    function _resolveHome(envPath) {
      return envPath[0] === "~" ? path.join(os.homedir(), envPath.slice(1)) : envPath;
    }
    function _configVault(options) {
      _log("Loading env from encrypted .env.vault");
      const parsed = DotenvModule._parseVault(options);
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      DotenvModule.populate(processEnv, parsed, options);
      return { parsed };
    }
    function configDotenv(options) {
      let dotenvPath = path.resolve(process.cwd(), ".env");
      let encoding = "utf8";
      const debug = Boolean(options && options.debug);
      if (options) {
        if (options.path != null) {
          dotenvPath = _resolveHome(options.path);
        }
        if (options.encoding != null) {
          encoding = options.encoding;
        }
      }
      try {
        const parsed = DotenvModule.parse(fs.readFileSync(dotenvPath, { encoding }));
        let processEnv = process.env;
        if (options && options.processEnv != null) {
          processEnv = options.processEnv;
        }
        DotenvModule.populate(processEnv, parsed, options);
        return { parsed };
      } catch (e) {
        if (debug) {
          _debug(`Failed to load ${dotenvPath} ${e.message}`);
        }
        return { error: e };
      }
    }
    function config(options) {
      const vaultPath = _vaultPath(options);
      if (_dotenvKey(options).length === 0) {
        return DotenvModule.configDotenv(options);
      }
      if (!fs.existsSync(vaultPath)) {
        _warn(`You set DOTENV_KEY but you are missing a .env.vault file at ${vaultPath}. Did you forget to build it?`);
        return DotenvModule.configDotenv(options);
      }
      return DotenvModule._configVault(options);
    }
    function decrypt(encrypted, keyStr) {
      const key = Buffer.from(keyStr.slice(-64), "hex");
      let ciphertext = Buffer.from(encrypted, "base64");
      const nonce = ciphertext.slice(0, 12);
      const authTag = ciphertext.slice(-16);
      ciphertext = ciphertext.slice(12, -16);
      try {
        const aesgcm = crypto.createDecipheriv("aes-256-gcm", key, nonce);
        aesgcm.setAuthTag(authTag);
        return `${aesgcm.update(ciphertext)}${aesgcm.final()}`;
      } catch (error) {
        const isRange = error instanceof RangeError;
        const invalidKeyLength = error.message === "Invalid key length";
        const decryptionFailed = error.message === "Unsupported state or unable to authenticate data";
        if (isRange || invalidKeyLength) {
          const msg = "INVALID_DOTENV_KEY: It must be 64 characters long (or more)";
          throw new Error(msg);
        } else if (decryptionFailed) {
          const msg = "DECRYPTION_FAILED: Please check your DOTENV_KEY";
          throw new Error(msg);
        } else {
          console.error("Error: ", error.code);
          console.error("Error: ", error.message);
          throw error;
        }
      }
    }
    function populate(processEnv, parsed, options = {}) {
      const debug = Boolean(options && options.debug);
      const override = Boolean(options && options.override);
      if (typeof parsed !== "object") {
        throw new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
      }
      for (const key of Object.keys(parsed)) {
        if (Object.prototype.hasOwnProperty.call(processEnv, key)) {
          if (override === true) {
            processEnv[key] = parsed[key];
          }
          if (debug) {
            if (override === true) {
              _debug(`"${key}" is already defined and WAS overwritten`);
            } else {
              _debug(`"${key}" is already defined and was NOT overwritten`);
            }
          }
        } else {
          processEnv[key] = parsed[key];
        }
      }
    }
    var DotenvModule = {
      configDotenv,
      _configVault,
      _parseVault,
      config,
      decrypt,
      parse,
      populate
    };
    module2.exports.configDotenv = DotenvModule.configDotenv;
    module2.exports._configVault = DotenvModule._configVault;
    module2.exports._parseVault = DotenvModule._parseVault;
    module2.exports.config = DotenvModule.config;
    module2.exports.decrypt = DotenvModule.decrypt;
    module2.exports.parse = DotenvModule.parse;
    module2.exports.populate = DotenvModule.populate;
    module2.exports = DotenvModule;
  }
});

// netlify/functions/deepgram_token/deepgram_token.ts
var import_sdk = __toESM(require_dist());
var import_dotenv = __toESM(require_main());
import_dotenv.default.config();
var deepgram = new import_sdk.Deepgram(process.env.DEEPGRAM_API_KEY);
var deepgramProjectId = process.env.DEEPGRAM_PROJECT_ID;
var buildCorsHeaders = (event, methods) => {
  let corsOrigin = process.env.URL;
  const cors = process.env.DEEPGRAM_SERVERLESS_CORS;
  const origin = event.headers["origin"] || event.headers["referer"];
  if (cors && origin) {
    const eventOrigin = new URL(origin);
    const corsDomains = [process.env.URL, process.env.DEPLOY_URL, ...cors.split(", ")];
    const thisCors = corsDomains.indexOf(eventOrigin.origin);
    if (thisCors > -1) {
      corsOrigin = corsDomains[thisCors];
    }
  }
  return {
    "Access-Control-Allow-Origin": corsOrigin,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": methods,
    Allow: methods,
    Vary: "Origin"
  };
};
exports.handler = async function(event) {
  console.log("process.env.DEEPGRAM_API_KEY:", process.env.DEEPGRAM_API_KEY);
  const headers = buildCorsHeaders(event, "GET, OPTIONS");
  switch (event.httpMethod) {
    case "OPTIONS":
      return {
        statusCode: 200,
        body: "OK",
        headers
      };
    case "GET":
      try {
        const key = await deepgram.keys.create(deepgramProjectId, "Temporary key", ["usage:write"], {
          timeToLive: 5
        });
        return {
          statusCode: 200,
          body: JSON.stringify(key),
          headers
        };
      } catch (err) {
        console.log(err);
        try {
          return {
            statusCode: 500,
            body: JSON.stringify(await deepgram.projects.list()),
            headers
          };
        } catch (errTwo) {
          return {
            statusCode: 500,
            body: "API key still doesnt work"
          };
        }
      }
    default:
      return {
        statusCode: 405,
        body: "Method Not Allowed",
        headers
      };
  }
};
